"""PyInstaller entry point.

Do not package picatalog/__main__.py directly: PyInstaller executes its input as a
top-level script, which means package-relative imports in __main__.py lose their
package context. Importing the package entry point here preserves that context.
"""
from picatalog.__main__ import main


if __name__ == "__main__":
    raise SystemExit(main())
