from __future__ import annotations

import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

from PIL import Image

from picatalog.catalog import Catalog
from picatalog.media import detect_media_kind, extract_media_metadata, resolve_file_type
from picatalog.native_dialogs import choose_directory
from picatalog.scanner import scan_sources
from picatalog.thumbnails import ensure_thumbnail


class PicaCatalogTests(unittest.TestCase):
    def test_exact_duplicate_detection(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            a = base / "source-a"
            b = base / "source-b"
            a.mkdir(); b.mkdir()
            (a / "first.bin").write_bytes(b"same bytes\n")
            (b / "second.bin").write_bytes(b"same bytes\n")
            (a / "unique.bin").write_bytes(b"different\n")

            catalog = Catalog(base / "catalog.db")
            summary = scan_sources(catalog, [str(a), str(b)], build_thumbnails=False)
            groups = catalog.duplicate_groups()

            self.assertEqual(summary.errors, 0)
            self.assertEqual(catalog.count_files(), 3)
            self.assertEqual(len(groups), 1)
            digest, size, paths = groups[0]
            self.assertEqual(size, len(b"same bytes\n"))
            self.assertEqual(len(digest), 64)
            self.assertEqual(set(paths), {str(a / "first.bin"), str(b / "second.bin")})

    def test_rescan_prunes_missing_file(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "source"; source.mkdir()
            victim = source / "victim.bin"; victim.write_bytes(b"content")
            catalog = Catalog(base / "catalog.db")
            scan_sources(catalog, [str(source)], build_thumbnails=False)
            victim.unlink()
            summary = scan_sources(catalog, [str(source)], build_thumbnails=False)
            self.assertEqual(summary.pruned, 1)
            self.assertEqual(catalog.count_files(), 0)

    def test_same_size_different_content_is_not_duplicate(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "source"; source.mkdir()
            (source / "one.bin").write_bytes(b"AAAA")
            (source / "two.bin").write_bytes(b"BBBB")
            catalog = Catalog(base / "catalog.db")
            scan_sources(catalog, [str(source)], build_thumbnails=False)
            self.assertEqual(catalog.duplicate_groups(), [])

    def test_photo_metadata_thumbnail_and_timeline(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "photos"; source.mkdir()
            photo = source / "camera.jpg"
            exif = Image.Exif()
            exif[271] = "ExampleCam"
            exif[272] = "Model One"
            exif[36867] = "2021:04:05 06:07:08"
            Image.new("RGB", (80, 60), (10, 20, 30)).save(photo, "JPEG", exif=exif)

            catalog = Catalog(base / "catalog.db")
            summary = scan_sources(catalog, [str(source)], build_thumbnails=False)
            self.assertEqual(summary.media_indexed, 1)
            row = catalog.media_files()[0]
            self.assertEqual(row.media_kind, "image")
            self.assertEqual((row.width, row.height), (80, 60))
            self.assertTrue((row.capture_time or "").startswith("2021-04-05T06:07:08"))
            self.assertEqual(row.camera_make, "ExampleCam")
            self.assertEqual(row.camera_model, "Model One")
            self.assertEqual(catalog.date_counts().get("2021-04"), 1)
            self.assertEqual(catalog.folder_counts().get(str(source)), 1)

            thumb = ensure_thumbnail(photo, "image", base / "thumbs")
            self.assertTrue(thumb.exists())
            with Image.open(thumb) as image:
                self.assertEqual(image.size, (220, 160))

    def test_video_is_catalogued_even_if_decoder_fails(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "videos"; source.mkdir()
            video = source / "broken.mp4"
            video.write_bytes(b"not really a video")
            catalog = Catalog(base / "catalog.db")
            scan_sources(catalog, [str(source)], build_thumbnails=False)
            row = catalog.media_files()[0]
            self.assertEqual(row.media_kind, "video")
            self.assertIsNotNone(row.capture_time)

    def test_old_chunk1_database_migrates_in_place(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            db = Path(td) / "legacy.db"
            con = sqlite3.connect(db)
            try:
                con.executescript("""
                    CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                    CREATE TABLE files (
                        id INTEGER PRIMARY KEY,
                        path TEXT NOT NULL UNIQUE,
                        source_root TEXT NOT NULL,
                        size INTEGER NOT NULL,
                        mtime_ns INTEGER NOT NULL,
                        sha256 TEXT,
                        scan_token TEXT NOT NULL,
                        last_error TEXT,
                        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                con.commit()
            finally:
                con.close()
            Catalog(db)
            con = sqlite3.connect(db)
            try:
                columns = {row[1] for row in con.execute("PRAGMA table_info(files)")}
            finally:
                con.close()
            for required in {"media_kind", "file_category", "file_type", "width", "height", "capture_time", "metadata_json", "media_error",
                             "source_id", "parent_path", "rating", "favorite", "caption"}:
                self.assertIn(required, columns)
            con = sqlite3.connect(db)
            try:
                tables = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            finally:
                con.close()
            for table in {"sources", "tags", "file_tags", "albums", "album_files"}:
                self.assertIn(table, tables)


    def test_hidden_paths_excluded_by_default_and_optional(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "source"; source.mkdir()
            (source / "visible.txt").write_text("visible")
            hidden_dir = source / ".cache"; hidden_dir.mkdir()
            (hidden_dir / "cached.bin").write_bytes(b"cache")
            (source / ".hidden.txt").write_text("hidden")
            catalog = Catalog(base / "catalog.db")

            summary = scan_sources(catalog, [str(source)], build_thumbnails=False)
            self.assertEqual(catalog.count_files(), 1)
            self.assertGreaterEqual(summary.hidden_skipped, 2)

            scan_sources(catalog, [str(source)], build_thumbnails=False, include_hidden=True)
            self.assertEqual(catalog.count_files(), 3)

            scan_sources(catalog, [str(source)], build_thumbnails=False, include_hidden=False)
            self.assertEqual(catalog.count_files(), 1)

    def test_file_type_resolution_for_common_non_media_files(self) -> None:
        self.assertEqual(resolve_file_type(Path("backup.iso"), use_file_command=False).category, "disk-image")
        self.assertEqual(resolve_file_type(Path("tool.AppImage"), use_file_command=False).label, "Linux AppImage")
        self.assertEqual(resolve_file_type(Path("archive.zip"), use_file_command=False).category, "archive")
        self.assertEqual(resolve_file_type(Path("manual.pdf"), use_file_command=False).label, "PDF document")
        self.assertEqual(resolve_file_type(Path("package.pkg.tar.zst"), use_file_command=False).category, "package")

    def test_clear_results_keeps_settings_and_start_over_clears_them(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "source"; source.mkdir()
            (source / "a.txt").write_text("a")
            catalog = Catalog(base / "catalog.db")
            catalog.set_setting("sources", str(source))
            catalog.set_setting("include_hidden", "1")
            scan_sources(catalog, [str(source)], build_thumbnails=False)
            self.assertEqual(catalog.count_files(), 1)

            cleared = catalog.clear_results()
            self.assertEqual(cleared, 1)
            self.assertEqual(catalog.count_files(), 0)
            self.assertEqual(catalog.get_setting("sources"), str(source))
            self.assertEqual(catalog.get_setting("include_hidden"), "1")

            scan_sources(catalog, [str(source)], build_thumbnails=False)
            catalog.start_over()
            self.assertEqual(catalog.count_files(), 0)
            self.assertEqual(catalog.get_setting("sources", "missing"), "missing")

    def test_png_scan_populates_media_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "images"; source.mkdir()
            photo = source / "sample.PNG"
            Image.new("RGBA", (47, 33), (15, 25, 35, 255)).save(photo, "PNG")
            catalog = Catalog(base / "catalog.db")
            summary = scan_sources(catalog, [str(source)], build_thumbnails=False)
            self.assertEqual(summary.errors, 0)
            row = catalog.media_files()[0]
            self.assertEqual(row.media_kind, "image")
            self.assertEqual(row.file_category, "image")
            self.assertEqual(row.file_type, "PNG image")
            self.assertEqual(row.mime_type, "image/png")
            self.assertEqual((row.width, row.height), (47, 33))

    def test_png_identification_by_extension_and_signature(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            normal = base / "photo.PNG"
            disguised = base / "photo_without_extension"
            Image.new("RGBA", (18, 14), (1, 2, 3, 255)).save(normal, "PNG")
            Image.new("RGBA", (19, 15), (4, 5, 6, 255)).save(disguised, "PNG")
            self.assertEqual(detect_media_kind(normal), ("image", "image/png"))
            self.assertEqual(resolve_file_type(normal, use_file_command=False).label, "PNG image")
            self.assertEqual(detect_media_kind(disguised), ("image", "image/png"))
            resolved = resolve_file_type(disguised, use_file_command=False)
            self.assertEqual(resolved.category, "image")
            self.assertEqual(resolved.label, "PNG image")

    def test_kde_picker_uses_kdialog(self) -> None:
        class Result:
            returncode = 0
            stdout = "/mnt/example\n"
        with patch("picatalog.native_dialogs._desktop_tokens", return_value="kde:plasma"), \
             patch("picatalog.native_dialogs.shutil.which", side_effect=lambda cmd: "/usr/bin/kdialog" if cmd == "kdialog" else None), \
             patch("picatalog.native_dialogs.subprocess.run", return_value=Result()) as run:
            chosen = choose_directory(title="Choose source", initial="/mnt")
        self.assertEqual(chosen, "/mnt/example")
        command = run.call_args.args[0]
        self.assertEqual(command[0], "kdialog")
        self.assertIn("--getexistingdirectory", command)

    def test_media_kind_detection(self) -> None:
        self.assertEqual(detect_media_kind(Path("a.JPG"))[0], "image")
        self.assertEqual(detect_media_kind(Path("a.MKV"))[0], "video")
        self.assertEqual(detect_media_kind(Path("a.iso"))[0], "other")

    def test_all_files_sorting_by_headers_backend(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "source"; source.mkdir()
            (source / "z-small.txt").write_bytes(b"1")
            (source / "a-large.iso").write_bytes(b"1234567890")
            (source / "m-medium.pdf").write_bytes(b"12345")
            catalog = Catalog(base / "catalog.db")
            scan_sources(catalog, [str(source)], build_thumbnails=False)
            by_size = catalog.all_files(sort_by="size", descending=True)
            self.assertEqual([Path(r.path).name for r in by_size], ["a-large.iso", "m-medium.pdf", "z-small.txt"])
            by_type = catalog.all_files(sort_by="type", descending=False)
            self.assertEqual(len(by_type), 3)
            by_path = catalog.all_files(sort_by="path", descending=False)
            self.assertEqual([Path(r.path).name for r in by_path], ["a-large.iso", "m-medium.pdf", "z-small.txt"])

    def test_chunk3_ratings_tags_captions_search_and_albums(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "photos"; source.mkdir()
            photo = source / "holiday.png"
            Image.new("RGB", (40, 30), (20, 30, 40)).save(photo, "PNG")
            other = source / "other.jpg"
            Image.new("RGB", (20, 20), (60, 70, 80)).save(other, "JPEG")
            catalog = Catalog(base / "catalog.db")
            scan_sources(catalog, [str(source)], build_thumbnails=False)

            catalog.set_annotations(str(photo), rating=5, favorite=True, caption="Beach sunset", tags=["Perth", "Holiday", "perth"])
            row = catalog.file_by_path(str(photo))
            self.assertIsNotNone(row)
            assert row is not None
            self.assertEqual(row.rating, 5)
            self.assertEqual(row.favorite, 1)
            self.assertEqual(row.caption, "Beach sunset")
            self.assertEqual(catalog.tags_for_file(str(photo)), ["Holiday", "Perth"])
            self.assertEqual([Path(r.path).name for r in catalog.media_files(favorite=True)], ["holiday.png"])
            self.assertEqual([Path(r.path).name for r in catalog.media_files(tag="perth")], ["holiday.png"])
            self.assertEqual([Path(r.path).name for r in catalog.media_files(query="sunset")], ["holiday.png"])
            self.assertEqual([Path(r.path).name for r in catalog.all_files(query="holiday")], ["holiday.png"])

            album_id = catalog.create_album("Best shots")
            self.assertTrue(catalog.add_file_to_album(str(photo), album_id))
            self.assertEqual([Path(r.path).name for r in catalog.media_files(album_id=album_id)], ["holiday.png"])
            self.assertEqual(catalog.albums_for_file(str(photo)), [(album_id, "Best shots")])

    def test_source_identity_rebases_catalogued_paths(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            old_root = base / "old-mount"; old_root.mkdir()
            new_root = base / "new-mount"; new_root.mkdir()
            catalog = Catalog(base / "catalog.db")
            source_id = "stable-source-1"
            catalog.register_source(source_id=source_id, identity_key="uuid:TEST|rel:Photos", configured_path=str(old_root), current_path=str(old_root), label="Photos")
            old_path = old_root / "folder" / "photo.jpg"
            catalog.upsert_file(path=str(old_path), source_root=str(old_root), source_id=source_id, parent_path=str(old_path.parent), size=123, mtime_ns=1, scan_token="one")
            catalog.set_annotations(str(old_path), rating=4, favorite=True, caption="keep me", tags=["Keep"])

            previous = catalog.register_source(source_id=source_id, identity_key="uuid:TEST|rel:Photos", configured_path=str(new_root), current_path=str(new_root), label="Photos")
            self.assertEqual(previous, str(old_root))
            new_path = new_root / "folder" / "photo.jpg"
            row = catalog.file_by_path(str(new_path))
            self.assertIsNotNone(row)
            assert row is not None
            self.assertEqual(row.rating, 4)
            self.assertEqual(row.favorite, 1)
            self.assertEqual(row.caption, "keep me")
            self.assertEqual(catalog.tags_for_file(str(new_path)), ["Keep"])
            records = catalog.source_records()
            self.assertEqual(len(records), 1)
            self.assertEqual(records[0].current_path, str(new_root))
            self.assertEqual(records[0].online, 1)
            catalog.mark_source_offline_by_path(str(new_root))
            self.assertEqual(catalog.source_records()[0].online, 0)

    def test_offline_source_is_preserved_and_reported_not_pruned(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            source = base / "drive"; source.mkdir()
            photo = source / "photo.jpg"
            Image.new("RGB", (12, 12), (1, 2, 3)).save(photo, "JPEG")
            catalog = Catalog(base / "catalog.db")
            first = scan_sources(catalog, [str(source)], build_thumbnails=False)
            self.assertEqual(first.sources_online, 1)
            self.assertEqual(catalog.count_files(), 1)
            photo.unlink(); source.rmdir()
            second = scan_sources(catalog, [str(source)], build_thumbnails=False)
            self.assertEqual(second.sources_offline, 1)
            self.assertEqual(second.errors, 0)
            self.assertEqual(catalog.count_files(), 1)
            self.assertEqual(catalog.source_records()[0].online, 0)


if __name__ == "__main__":
    unittest.main()
