from __future__ import annotations

import tempfile
from pathlib import Path
from types import SimpleNamespace

from PIL import Image

from picatalog.catalog import Catalog
from picatalog.scanner import scan_sources
from picatalog.ui import PicaCatalogApp


def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        source = base / "source"
        source.mkdir()
        (source / "small.txt").write_bytes(b"1")
        (source / "large.iso").write_bytes(b"x" * 900)
        Image.new("RGB", (80, 50), (20, 40, 90)).save(source / "photo.png", "PNG")
        catalog = Catalog(base / "catalog.db")
        scan_sources(catalog, [str(source)], build_thumbnails=False)
        catalog.set_setting("sources", str(source))

        app = PicaCatalogApp(catalog)
        app.update_idletasks()
        app.update()

        # All Files header sorting is live and backed by catalog ordering.
        app._show_page("files")
        app.update()
        assert app.library_tree.heading("size", "command"), "Size header has no sort command"
        app._sort_all_files("size")  # ascending
        first = app.library_tree.get_children()[0]
        assert Path(app.file_rows_by_iid[first].path).name == "small.txt"
        app._sort_all_files("size")  # descending
        first = app.library_tree.get_children()[0]
        assert Path(app.file_rows_by_iid[first].path).name == "large.iso"

        # Switching back to a clean Library page must not rebuild the thumbnail grid.
        app._show_page("library")
        app.update()
        app._show_page("storage")
        calls: list[bool] = []
        original_refresh = app._refresh_media_grid
        app._refresh_media_grid = lambda *a, **k: calls.append(True)  # type: ignore[method-assign]
        app._show_page("library")
        assert not calls, "Clean Library tab was rebuilt while switching tabs"
        app._refresh_media_grid = original_refresh  # type: ignore[method-assign]

        # Linux/X11 wheel events use Button-4/5. Verify scrolling while pointer is over the canvas.
        app.media_canvas.configure(scrollregion=(0, 0, 500, 5000))
        app.update_idletasks()
        left, top = app.media_canvas.winfo_rootx(), app.media_canvas.winfo_rooty()
        app.winfo_pointerxy = lambda: (left + 20, top + 20)  # type: ignore[method-assign]
        before = app.media_canvas.yview()[0]
        result = app._mousewheel_media(SimpleNamespace(num=5, delta=0))
        after = app.media_canvas.yview()[0]
        assert result == "break"
        assert after > before, (before, after)

        app.destroy()
    print("GUI smoke: sortable headers + cached tabs + Linux mouse wheel passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
