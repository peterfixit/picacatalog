#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION")"
ENTRY="$ROOT/packaging/pyinstaller_entry.py"

if [[ ! -f "$ENTRY" ]]; then
  echo "ERROR: PyInstaller entry point is missing: $ENTRY" >&2
  exit 2
fi

python3 -m venv .venv-build
source .venv-build/bin/activate
python -m pip install --upgrade pip wheel setuptools
python -m pip install -r requirements-build.txt

rm -rf build dist
pyinstaller \
  --noconfirm \
  --clean \
  --name picatalog \
  --windowed \
  --paths "$ROOT/src" \
  --hidden-import tkinter \
  --collect-all PIL \
  --add-data "$ROOT/src/picatalog/assets:picatalog/assets" \
  "$ENTRY"

EXE="$ROOT/dist/picatalog/picatalog"
if [[ ! -x "$EXE" ]]; then
  echo "ERROR: PyInstaller did not create the expected executable: $EXE" >&2
  exit 3
fi

echo
echo "Running packaged executable smoke tests…"
"$EXE" --help >/dev/null
"$EXE" --version | grep -q "$VERSION"

SMOKE_DIR="$(mktemp -d -t picatalog-build-smoke.XXXXXX)"
cleanup() { rm -rf "$SMOKE_DIR"; }
trap cleanup EXIT
mkdir -p "$SMOKE_DIR/source-a" "$SMOKE_DIR/source-b"
printf 'PicaCatalog packaged duplicate smoke test\n' > "$SMOKE_DIR/source-a/a.bin"
cp "$SMOKE_DIR/source-a/a.bin" "$SMOKE_DIR/source-b/b.bin"
printf 'unique data\n' > "$SMOKE_DIR/source-a/unique.bin"
printf 'fake iso content\n' > "$SMOKE_DIR/source-a/recovery.iso"
mkdir -p "$SMOKE_DIR/source-a/.cache"
printf 'hidden cache data\n' > "$SMOKE_DIR/source-a/.cache/ignored.bin"

python - "$SMOKE_DIR/source-a/test.jpg" "$SMOKE_DIR/source-a/test.PNG" "$SMOKE_DIR/source-a/no_extension" <<'PY'
from PIL import Image
import sys
Image.new("RGB", (32, 24), (120, 80, 40)).save(sys.argv[1], "JPEG")
Image.new("RGBA", (31, 23), (20, 110, 180, 255)).save(sys.argv[2], "PNG")
Image.new("RGBA", (29, 21), (180, 40, 90, 255)).save(sys.argv[3], "PNG")
PY

SMOKE_OUTPUT="$(
  XDG_DATA_HOME="$SMOKE_DIR/data" XDG_CACHE_HOME="$SMOKE_DIR/cache" "$EXE" \
    --db "$SMOKE_DIR/catalog.db" \
    --scan "$SMOKE_DIR/source-a" \
    --scan "$SMOKE_DIR/source-b" \
    --media-summary \
    --type-summary \
    --search recovery \
    --duplicates
)"

if ! grep -q 'copies=2' <<<"$SMOKE_OUTPUT"; then
  echo "ERROR: packaged executable launched, but duplicate smoke test failed." >&2
  echo "$SMOKE_OUTPUT" >&2
  exit 4
fi
if ! grep -q 'images=3' <<<"$SMOKE_OUTPUT"; then
  echo "ERROR: packaged executable launched, but media/Pillow smoke test failed." >&2
  echo "$SMOKE_OUTPUT" >&2
  exit 5
fi
if ! grep -q 'disk-image=1' <<<"$SMOKE_OUTPUT"; then
  echo "ERROR: packaged executable launched, but resolved file-type smoke test failed." >&2
  echo "$SMOKE_OUTPUT" >&2
  exit 6
fi
if ! grep -q 'hidden_skipped=1' <<<"$SMOKE_OUTPUT"; then
  echo "ERROR: packaged executable launched, but hidden-path exclusion smoke test failed." >&2
  echo "$SMOKE_OUTPUT" >&2
  exit 7
fi
if ! grep -q "matches=1" <<<"$SMOKE_OUTPUT" || ! grep -q "recovery.iso" <<<"$SMOKE_OUTPUT"; then
  echo "ERROR: packaged executable launched, but Chunk 3 local-search smoke test failed." >&2
  echo "$SMOKE_OUTPUT" >&2
  exit 8
fi

trap - EXIT
cleanup

echo "Packaged executable media + file-type + hidden-path + local-search + duplicate smoke tests passed."
echo
printf 'Standalone build created at: %s\n' "$EXE"
printf 'Version: %s\n' "$VERSION"
printf 'Test it with: %s\n' "$EXE"
