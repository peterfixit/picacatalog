# PicaCatalog build chunks

## Chunk 1 — 0.1.x — complete
- Local SQLite catalogue
- Multi-source recursive scanning
- Exact duplicate detection
- AppImage build chain

## Chunk 2 — 0.2.x — complete
- Photo/video recognition and metadata
- Thumbnail cache and media grid
- Folder/date navigation
- Resolved general file types
- Hidden-path include/exclude policy
- Uppy-style desktop shell
- Clear Results / Start Over
- Activity logging, KDE picker and desktop icon integration

## Chunk 3 — 0.3.x — active
- Sortable All Files columns
- Cached/dirty page rendering and Linux mouse-wheel fixes
- Albums
- Ratings/favourites
- Tags/captions
- Search/filtering
- Persistent removable-drive/offline identities

### 0.3.0 safety boundary
No source move, rename, overwrite or automatic delete operations exist yet. User organisation metadata is stored in PicaCatalog's SQLite database, not written into the source media.

## Chunk 4 — planned
- Similar-photo review
- Duplicate review/selection workflow
- Consolidation planning
- Dry-run manifests
- Explicit keep/remove choices before any destructive capability exists

## Chunk 5 — planned
- Verified copy/move target workflow
- Post-copy hash verification
- Explicitly gated duplicate deletion
- Recovery/audit logs
