#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT="$(dirname "$ROOT")"
NAME="$(basename "$ROOT")"
cd "$PARENT"
tar --exclude="$NAME/.venv-build" \
    --exclude="$NAME/.venv-dev" \
    --exclude="$NAME/.venv-test" \
    --exclude="$NAME/build" \
    --exclude="$NAME/dist" \
    --exclude="$NAME/release" \
    --exclude="$NAME/.tools" \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    -czf "$NAME.tar.gz" "$NAME"
sha256sum "$NAME.tar.gz" > "$NAME.tar.gz.sha256"
echo "$PARENT/$NAME.tar.gz"
echo "$PARENT/$NAME.tar.gz.sha256"
