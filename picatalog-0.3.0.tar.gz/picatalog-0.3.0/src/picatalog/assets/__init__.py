# PicaCatalog runtime assets
