from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .catalog import Catalog
from .logging_setup import configure_logging
from .paths import default_db_path
from .scanner import scan_sources


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="picatalog", description="Offline local file/media catalogue and exact duplicate scanner")
    parser.add_argument("--version", action="version", version=f"PicaCatalog {__version__}")
    parser.add_argument("--db", type=Path, default=default_db_path(), help="SQLite catalogue path")
    parser.add_argument("--scan", action="append", default=[], metavar="PATH", help="Headless scan source; repeatable")
    parser.add_argument("--duplicates", action="store_true", help="Print exact duplicate groups and exit")
    parser.add_argument("--media-summary", action="store_true", help="Print photo/video catalogue counts")
    parser.add_argument("--type-summary", action="store_true", help="Print resolved file category counts")
    parser.add_argument("--search", metavar="QUERY", help="Search path, resolved type, caption and tags")
    parser.add_argument("--include-hidden", action="store_true", help="Include dot-files and dot-folders such as .cache")
    parser.add_argument("--no-thumbnails", action="store_true", help="Do not build thumbnail cache during headless scan")
    parser.add_argument("--clear-results", action="store_true", help="Clear indexed catalogue results but keep saved settings")
    parser.add_argument("--start-over", action="store_true", help="Clear indexed results and all saved PicaCatalog settings")
    parser.add_argument("--verbose", action="store_true")
    return parser


def _print_duplicates(catalog: Catalog) -> None:
    groups = catalog.duplicate_groups()
    if not groups:
        print("No exact duplicate groups found."); return
    for index, (digest, size, paths) in enumerate(groups, start=1):
        print(f"\n[{index}] {digest}  size={size}  copies={len(paths)}")
        for path in paths: print(f"  {path}")


def _print_media_summary(catalog: Catalog) -> None:
    counts = catalog.media_counts()
    print(f"images={counts.get('image',0)} videos={counts.get('video',0)} other={counts.get('other',0)}")


def _print_type_summary(catalog: Catalog) -> None:
    counts = catalog.category_counts()
    print(" ".join(f"{key}={value}" for key, value in sorted(counts.items())))


def _print_search(catalog: Catalog, query: str) -> None:
    rows = catalog.all_files(limit=5000, query=query)
    print(f"search={query!r} matches={len(rows)}")
    for row in rows:
        print(f"  {row.path}\t{row.file_type or row.file_category}")


def main() -> int:
    args = build_parser().parse_args(); logger = configure_logging(args.verbose); catalog = Catalog(args.db)

    if args.start_over:
        count = catalog.start_over(); print(f"start-over: cleared {count} catalogue records and all settings")
        return 0
    if args.clear_results:
        count = catalog.clear_results(); print(f"clear-results: cleared {count} catalogue records; settings kept")
        return 0

    if args.scan:
        def progress(event: dict) -> None:
            if event.get("message"): print(event["message"])
        summary = scan_sources(catalog,args.scan,progress=progress,logger=logger,
                               build_thumbnails=not args.no_thumbnails,include_hidden=args.include_hidden)
        print(f"sources={summary.sources} files_seen={summary.files_seen} indexed={summary.indexed} "
              f"types_resolved={summary.types_resolved} media_indexed={summary.media_indexed} "
              f"thumbnails={summary.thumbnails_generated} hashed={summary.hashed} hidden_skipped={summary.hidden_skipped} "
              f"errors={summary.errors} pruned={summary.pruned} elapsed={summary.elapsed_seconds:.2f}s")
        if args.media_summary: _print_media_summary(catalog)
        if args.type_summary: _print_type_summary(catalog)
        if args.search: _print_search(catalog, args.search)
        if args.duplicates: _print_duplicates(catalog)
        return 0 if summary.errors == 0 else 2

    if args.media_summary: _print_media_summary(catalog)
    if args.type_summary: _print_type_summary(catalog)
    if args.search: _print_search(catalog, args.search)
    if args.duplicates: _print_duplicates(catalog)
    if args.media_summary or args.type_summary or args.search or args.duplicates: return 0

    try: from .ui import PicaCatalogApp
    except Exception as exc:
        logger.exception("Unable to load GUI"); print(f"Unable to load GUI: {exc}", file=sys.stderr); return 1
    app = PicaCatalogApp(catalog); app.mainloop(); return 0


if __name__ == "__main__": raise SystemExit(main())
