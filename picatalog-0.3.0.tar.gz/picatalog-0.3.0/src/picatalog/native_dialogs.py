from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from tkinter import filedialog


def _desktop_tokens() -> str:
    return ":".join(
        value for value in (
            os.environ.get("XDG_CURRENT_DESKTOP", ""),
            os.environ.get("XDG_SESSION_DESKTOP", ""),
            os.environ.get("DESKTOP_SESSION", ""),
        ) if value
    ).lower()


def choose_directory(*, parent=None, title: str = "Choose folder", initial: str | None = None) -> str:
    """Open the desktop's native directory chooser when practical.

    KDE/Plasma uses kdialog, which presents the KDE file dialog/KFileWidget-style
    picker. Other desktops can use Zenity. Tk's chooser remains the final fallback
    so the application is still usable on minimal/offline systems.
    """
    start = str(Path(initial or Path.home()).expanduser())
    desktop = _desktop_tokens()

    if ("kde" in desktop or "plasma" in desktop) and shutil.which("kdialog"):
        proc = subprocess.run(
            ["kdialog", "--title", title, "--getexistingdirectory", start],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=False,
        )
        if proc.returncode == 0:
            return proc.stdout.strip()
        return ""

    if shutil.which("zenity"):
        start_path = str(Path(start).resolve()) if Path(start).exists() else str(Path.home())
        proc = subprocess.run(
            ["zenity", "--file-selection", "--directory", f"--title={title}", f"--filename={start_path.rstrip('/')}/"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=False,
        )
        if proc.returncode == 0:
            return proc.stdout.strip()
        return ""

    return filedialog.askdirectory(parent=parent, title=title, initialdir=start) or ""
