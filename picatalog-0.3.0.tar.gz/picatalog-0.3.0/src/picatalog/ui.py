from __future__ import annotations

import json
import queue
import shutil
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, simpledialog, ttk

from PIL import Image, ImageTk, ImageOps

from . import __version__
from .catalog import Catalog, FileRow
from .logging_setup import configure_logging
from .native_dialogs import choose_directory
from .paths import log_dir, thumbnail_dir
from .scanner import scan_sources
from .thumbnails import ensure_thumbnail

BG = "#0a1020"
SIDEBAR = "#0e172b"
PANEL = "#131e35"
CARD = "#182540"
CARD_HOVER = "#203052"
BORDER = "#2a3a5f"
TEXT = "#eef2ff"
MUTED = "#92a4cc"
ACCENT = "#7064ff"
ACCENT_HOVER = "#8278ff"
BLUE = "#3b82f6"
SUCCESS = "#2dd4a3"
DANGER = "#f05d68"
WARNING = "#f7b955"

CATEGORY_ICONS = {
    "image": "▧", "video": "▶", "audio": "♪", "document": "▤", "archive": "◫",
    "package": "⬢", "disk-image": "◉", "database": "▦", "font": "A", "code": "⌘",
    "data": "{}", "other": "•",
}


class PicaCatalogApp(tk.Tk):
    def __init__(self, catalog: Catalog):
        super().__init__(className="PicaCatalog")
        self.catalog = catalog
        self.logger = configure_logging()
        self.events: queue.Queue[dict] = queue.Queue()
        self.scan_thread: threading.Thread | None = None
        self.thumb_refs: list[ImageTk.PhotoImage] = []
        self.current_filter: tuple[str, object | None] = ("all", None)
        self.nav_filters: dict[str, tuple[str, object | None]] = {}
        self.file_sort_column = "path"
        self.file_sort_desc = False
        self.search_query = ""
        self.page_dirty = {"library": True, "files": True, "duplicates": True, "storage": True}
        self.nav_dirty = True
        self.stats_dirty = True
        self.media_grid_filter_key: tuple[object, ...] | None = None
        self.current_media: FileRow | None = None
        self.preview_ref: ImageTk.PhotoImage | None = None
        self.current_page = "library"
        self.page_frames: dict[str, tk.Widget] = {}
        self.nav_buttons: dict[str, tk.Button] = {}

        self.title(f"PicaCatalog {__version__}")
        self.geometry("1480x900")
        self.minsize(1120, 720)
        self.configure(bg=BG)
        self._icon_ref: tk.PhotoImage | None = None
        self._set_app_icon()
        self._configure_style()
        self._build_shell()
        self._load_settings()
        self.after(100, self._poll_events)

    def _set_app_icon(self) -> None:
        icon_path = Path(__file__).resolve().parent / "assets" / "picatalog.png"
        if not icon_path.exists():
            return
        try:
            self._icon_ref = tk.PhotoImage(file=str(icon_path))
            self.iconphoto(True, self._icon_ref)
        except tk.TclError as exc:
            self.logger.warning("Unable to set application icon: %s", exc)

    def _set_initial_activity_size(self) -> None:
        try:
            height = self.workspace_pane.winfo_height()
            if height > 300:
                self.workspace_pane.sash_place(0, 0, max(220, height - 150))
        except tk.TclError:
            pass

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure(".", background=BG, foreground=TEXT, fieldbackground=CARD, bordercolor=BORDER,
                        lightcolor=BORDER, darkcolor=BORDER, troughcolor=PANEL, font=("DejaVu Sans", 10))
        style.configure("TFrame", background=BG)
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("Card.TFrame", background=CARD, relief="flat")
        style.configure("TLabel", background=BG, foreground=TEXT)
        style.configure("Panel.TLabel", background=PANEL, foreground=TEXT)
        style.configure("Muted.TLabel", background=BG, foreground=MUTED)
        style.configure("Card.TLabel", background=CARD, foreground=TEXT)
        style.configure("CardMuted.TLabel", background=CARD, foreground=MUTED)
        style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("DejaVu Sans", 18, "bold"))
        style.configure("Heading.TLabel", background=BG, foreground=TEXT, font=("DejaVu Sans", 12, "bold"))
        style.configure("TButton", background=CARD, foreground=TEXT, borderwidth=0, padding=(12, 8))
        style.map("TButton", background=[("active", CARD_HOVER), ("pressed", BORDER)])
        style.configure("Accent.TButton", background=ACCENT, foreground="white", padding=(14, 9), font=("DejaVu Sans", 10, "bold"))
        style.map("Accent.TButton", background=[("active", ACCENT_HOVER), ("pressed", "#5d52db")])
        style.configure("Danger.TButton", background="#482331", foreground="#ffdfe3", padding=(12, 8))
        style.map("Danger.TButton", background=[("active", "#63303f")])
        style.configure("TCheckbutton", background=PANEL, foreground=TEXT)
        style.map("TCheckbutton", background=[("active", PANEL)], foreground=[("active", TEXT)])
        style.configure("TEntry", fieldbackground=CARD, foreground=TEXT, insertcolor=TEXT, bordercolor=BORDER, padding=7)
        style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT, rowheight=27,
                        bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER)
        style.map("Treeview", background=[("selected", ACCENT)], foreground=[("selected", "white")])
        style.configure("Treeview.Heading", background=PANEL, foreground=TEXT, relief="flat", padding=(6, 7))
        style.map("Treeview.Heading", background=[("active", CARD_HOVER)])
        style.configure("TPanedwindow", background=BG)
        style.configure("TLabelframe", background=PANEL, foreground=TEXT, bordercolor=BORDER)
        style.configure("TLabelframe.Label", background=PANEL, foreground=TEXT, font=("DejaVu Sans", 10, "bold"))
        style.configure("Horizontal.TProgressbar", troughcolor=PANEL, background=ACCENT, bordercolor=PANEL)

    def _build_shell(self) -> None:
        shell = tk.Frame(self, bg=BG)
        shell.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(shell, bg=SIDEBAR, width=205)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        brand = tk.Frame(self.sidebar, bg=SIDEBAR)
        brand.pack(fill="x", padx=16, pady=(18, 22))
        logo = tk.Label(brand, text="◈", bg=ACCENT, fg="white", font=("DejaVu Sans", 18, "bold"), width=2, height=1)
        logo.pack(side="left")
        tk.Label(brand, text="PicaCatalog", bg=SIDEBAR, fg=TEXT, font=("DejaVu Sans", 14, "bold")).pack(side="left", padx=(10, 0))

        for page, icon, label in [
            ("library", "▦", "Library"), ("files", "≡", "All files"),
            ("duplicates", "⧉", "Duplicates"), ("storage", "⚙", "Storage"),
        ]:
            btn = tk.Button(self.sidebar, text=f"{icon}   {label}", anchor="w", relief="flat", bd=0,
                            bg=SIDEBAR, fg=MUTED, activebackground=CARD, activeforeground=TEXT,
                            font=("DejaVu Sans", 10, "bold"), padx=18, pady=11,
                            command=lambda p=page: self._show_page(p))
            btn.pack(fill="x", padx=8, pady=2)
            self.nav_buttons[page] = btn

        tk.Frame(self.sidebar, bg=BORDER, height=1).pack(fill="x", padx=16, pady=16)
        tk.Label(self.sidebar, text="CHUNK 3", bg=SIDEBAR, fg=ACCENT_HOVER,
                 font=("DejaVu Sans", 9, "bold")).pack(anchor="w", padx=20)
        tk.Label(self.sidebar, text="Offline · local only\nNo source deletion", justify="left",
                 bg=SIDEBAR, fg=MUTED, font=("DejaVu Sans", 9)).pack(anchor="w", padx=20, pady=(4, 0))

        main = tk.Frame(shell, bg=BG)
        main.pack(side="left", fill="both", expand=True)

        header = tk.Frame(main, bg=BG)
        header.pack(fill="x", padx=20, pady=(16, 8))
        titlebox = tk.Frame(header, bg=BG)
        titlebox.pack(side="left", fill="x", expand=True)
        self.page_title = tk.StringVar(value="Library")
        tk.Label(titlebox, textvariable=self.page_title, bg=BG, fg=TEXT, font=("DejaVu Sans", 18, "bold")).pack(anchor="w")
        tk.Label(titlebox, text="Offline catalogue · albums · ratings · tags · fast local search",
                 bg=BG, fg=MUTED, font=("DejaVu Sans", 9)).pack(anchor="w", pady=(2, 0))

        actions = tk.Frame(header, bg=BG)
        actions.pack(side="right")
        self.scan_button = ttk.Button(actions, text="↻  Scan", style="Accent.TButton", command=self._start_scan)
        self.scan_button.pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="⌫  Clear results", command=self._clear_results).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="⟲  Start over", style="Danger.TButton", command=self._start_over).pack(side="left")

        searchbar = tk.Frame(main, bg=BG)
        searchbar.pack(fill="x", padx=20, pady=(0, 8))
        tk.Label(searchbar, text="⌕", bg=BG, fg=ACCENT_HOVER, font=("DejaVu Sans", 15, "bold")).pack(side="left", padx=(0, 6))
        self.search_var = tk.StringVar(value="")
        self.search_entry = ttk.Entry(searchbar, textvariable=self.search_var)
        self.search_entry.pack(side="left", fill="x", expand=True)
        self.search_entry.bind("<Return>", lambda _event: self._apply_search())
        ttk.Button(searchbar, text="Search", command=self._apply_search).pack(side="left", padx=(7, 0))
        ttk.Button(searchbar, text="Clear", command=self._clear_search).pack(side="left", padx=(7, 0))
        self.search_hint = tk.StringVar(value="Search path, type, caption or tags")
        tk.Label(searchbar, textvariable=self.search_hint, bg=BG, fg=MUTED, font=("DejaVu Sans", 8)).pack(side="left", padx=(10, 0))

        stats = tk.Frame(main, bg=BG)
        stats.pack(fill="x", padx=20, pady=(2, 10))
        self.files_stat = self._stat_card(stats, "▤", "FILES", "0")
        self.photos_stat = self._stat_card(stats, "▧", "PHOTOS / VIDEOS", "0 / 0")
        self.dups_stat = self._stat_card(stats, "⧉", "DUPLICATE GROUPS", "0")
        self.hidden_stat = self._stat_card(stats, "◌", "HIDDEN PATHS", "Excluded", command=self._toggle_hidden_paths)

        self.progress = ttk.Progressbar(main, mode="indeterminate")
        self.progress.pack(fill="x", padx=20, pady=(0, 8))

        self.workspace_pane = tk.PanedWindow(
            main, orient=tk.VERTICAL, bg=BG, sashwidth=7, sashrelief="flat",
            bd=0, opaqueresize=True,
        )
        self.workspace_pane.pack(fill="both", expand=True, padx=20, pady=(0, 14))

        page_host = tk.Frame(self.workspace_pane, bg=BG)
        self.pages = tk.Frame(page_host, bg=BG)
        self.pages.pack(fill="both", expand=True)
        self._build_library_page()
        self._build_files_page()
        self._build_duplicates_page()
        self._build_storage_page()

        activity_wrap = tk.Frame(self.workspace_pane, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        activity_head = tk.Frame(activity_wrap, bg=PANEL)
        activity_head.pack(fill="x", padx=10, pady=(7, 3))
        tk.Label(activity_head, text="ACTIVITY", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(side="left")
        tk.Label(activity_head, text=str(log_dir() / "picatalog.log"), bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8)).pack(side="left", padx=(10, 0))
        ttk.Button(activity_head, text="Open log", command=lambda: self._xdg_open(log_dir() / "picatalog.log")).pack(side="right", padx=(8, 0))
        self.status_var = tk.StringVar(value="Ready")
        tk.Label(activity_head, textvariable=self.status_var, bg=PANEL, fg=SUCCESS, font=("DejaVu Sans", 9)).pack(side="right")
        text_wrap = tk.Frame(activity_wrap, bg="#09101d")
        text_wrap.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.activity_text = tk.Text(text_wrap, height=6, bg="#09101d", fg="#b9c7e7", insertbackground=TEXT,
                                     relief="flat", bd=0, font=("DejaVu Sans Mono", 9), state="disabled")
        activity_scroll = ttk.Scrollbar(text_wrap, orient="vertical", command=self.activity_text.yview)
        self.activity_text.configure(yscrollcommand=activity_scroll.set)
        self.activity_text.pack(side="left", fill="both", expand=True)
        activity_scroll.pack(side="right", fill="y")
        self.workspace_pane.add(page_host, minsize=300)
        self.workspace_pane.add(activity_wrap, minsize=72)
        self.after_idle(self._set_initial_activity_size)
        self._activity("[INFO] PicaCatalog ready. Source files are read-only in this chunk.")
        self._show_page("library")

    def _stat_card(self, parent: tk.Widget, icon: str, label: str, initial: str, command=None) -> tk.StringVar:
        cursor = "hand2" if command else ""
        frame = tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1, cursor=cursor)
        frame.pack(side="left", fill="x", expand=True, padx=(0, 8))
        icon_widget = tk.Label(frame, text=icon, bg=CARD, fg=ACCENT_HOVER, font=("DejaVu Sans", 18, "bold"), cursor=cursor)
        icon_widget.pack(side="left", padx=(13, 10), pady=10)
        text = tk.Frame(frame, bg=CARD, cursor=cursor); text.pack(side="left", fill="x", expand=True, pady=8)
        label_widget = tk.Label(text, text=label, bg=CARD, fg=MUTED, font=("DejaVu Sans", 8, "bold"), cursor=cursor)
        label_widget.pack(anchor="w")
        var = tk.StringVar(value=initial)
        value_widget = tk.Label(text, textvariable=var, bg=CARD, fg=TEXT, font=("DejaVu Sans", 12, "bold"), cursor=cursor)
        value_widget.pack(anchor="w", pady=(2, 0))
        if command:
            for widget in (frame, icon_widget, text, label_widget, value_widget):
                widget.bind("<Button-1>", lambda _event, cb=command: cb())
        return var

    def _build_library_page(self) -> None:
        page = tk.Frame(self.pages, bg=BG)
        self.page_frames["library"] = page
        paned = ttk.Panedwindow(page, orient="horizontal")
        paned.pack(fill="both", expand=True)
        nav_frame = tk.Frame(paned, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        grid_frame = tk.Frame(paned, bg=BG)
        details_frame = tk.Frame(paned, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        paned.add(nav_frame, weight=1)
        paned.add(grid_frame, weight=4)
        paned.add(details_frame, weight=2)

        tk.Label(nav_frame, text="LIBRARY", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=10, pady=(10, 5))
        tree_wrap = tk.Frame(nav_frame, bg=PANEL)
        tree_wrap.pack(fill="both", expand=True, padx=7, pady=(0, 7))
        self.nav_tree = ttk.Treeview(tree_wrap, show="tree", selectmode="browse")
        scroll = ttk.Scrollbar(tree_wrap, orient="vertical", command=self.nav_tree.yview)
        self.nav_tree.configure(yscrollcommand=scroll.set)
        self.nav_tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.nav_tree.bind("<<TreeviewSelect>>", self._on_nav_select)

        top = tk.Frame(grid_frame, bg=BG)
        top.pack(fill="x", padx=8, pady=(0, 6))
        self.media_heading = tk.StringVar(value="All media")
        self.media_count_var = tk.StringVar(value="0 items")
        tk.Label(top, textvariable=self.media_heading, bg=BG, fg=TEXT, font=("DejaVu Sans", 12, "bold")).pack(side="left")
        tk.Label(top, textvariable=self.media_count_var, bg=BG, fg=MUTED, font=("DejaVu Sans", 9)).pack(side="right")

        canvas_wrap = tk.Frame(grid_frame, bg=BG)
        canvas_wrap.pack(fill="both", expand=True, padx=4)
        self.media_canvas = tk.Canvas(canvas_wrap, bg=BG, highlightthickness=0)
        media_scroll = ttk.Scrollbar(canvas_wrap, orient="vertical", command=self.media_canvas.yview)
        self.media_canvas.configure(yscrollcommand=media_scroll.set)
        self.media_canvas.pack(side="left", fill="both", expand=True)
        media_scroll.pack(side="right", fill="y")
        self.media_grid = tk.Frame(self.media_canvas, bg=BG)
        self.media_window = self.media_canvas.create_window((0, 0), window=self.media_grid, anchor="nw")
        self.media_grid.bind("<Configure>", self._sync_media_scrollregion)
        self.media_canvas.bind("<Configure>", self._resize_media_window)
        # Linux/X11 sends Button-4/5 rather than MouseWheel. bind_all is intentional;
        # _mousewheel_media checks pointer position before consuming the event.
        self.bind_all("<MouseWheel>", self._mousewheel_media, add="+")
        self.bind_all("<Button-4>", self._mousewheel_media, add="+")
        self.bind_all("<Button-5>", self._mousewheel_media, add="+")

        tk.Label(details_frame, text="DETAILS & ORGANISE", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=10, pady=(10, 5))
        self.preview_label = tk.Label(details_frame, text="Select a photo or video", bg="#0b1324", fg=MUTED, anchor="center", height=9)
        self.preview_label.pack(fill="x", padx=10, pady=(0, 8))
        self.details_text = tk.Text(details_frame, wrap="word", height=9, bg=PANEL, fg=TEXT, insertbackground=TEXT, relief="flat", bd=0,
                                    state="disabled", font=("DejaVu Sans", 9))
        self.details_text.pack(fill="both", expand=True, padx=10)

        organise = tk.Frame(details_frame, bg="#111b30", highlightbackground=BORDER, highlightthickness=1)
        organise.pack(fill="x", padx=10, pady=(8, 4))
        row1 = tk.Frame(organise, bg="#111b30")
        row1.pack(fill="x", padx=8, pady=(8, 4))
        self.favorite_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="★ Favourite", variable=self.favorite_var).pack(side="left")
        tk.Label(row1, text="Rating", bg="#111b30", fg=MUTED).pack(side="left", padx=(14, 5))
        self.rating_var = tk.StringVar(value="0")
        self.rating_combo = ttk.Combobox(row1, textvariable=self.rating_var, values=("0", "1", "2", "3", "4", "5"), width=4, state="readonly")
        self.rating_combo.pack(side="left")

        tk.Label(organise, text="Caption", bg="#111b30", fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=8, pady=(4, 2))
        self.caption_var = tk.StringVar(value="")
        ttk.Entry(organise, textvariable=self.caption_var).pack(fill="x", padx=8)
        tk.Label(organise, text="Tags (comma separated)", bg="#111b30", fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=8, pady=(6, 2))
        self.tags_var = tk.StringVar(value="")
        ttk.Entry(organise, textvariable=self.tags_var).pack(fill="x", padx=8)

        albumrow = tk.Frame(organise, bg="#111b30")
        albumrow.pack(fill="x", padx=8, pady=(7, 8))
        self.album_var = tk.StringVar(value="")
        self.album_combo = ttk.Combobox(albumrow, textvariable=self.album_var, state="readonly", width=22)
        self.album_combo.pack(side="left", fill="x", expand=True)
        ttk.Button(albumrow, text="Add to album", command=self._add_selected_to_album).pack(side="left", padx=(6, 0))
        ttk.Button(albumrow, text="＋", width=3, command=self._create_album).pack(side="left", padx=(5, 0))
        ttk.Button(organise, text="Save rating / caption / tags", style="Accent.TButton", command=self._save_selected_metadata).pack(fill="x", padx=8, pady=(0, 8))

        buttons = tk.Frame(details_frame, bg=PANEL)
        buttons.pack(fill="x", padx=10, pady=(4, 10))
        ttk.Button(buttons, text="↗  View / open", command=self._open_selected_media).pack(side="left")
        ttk.Button(buttons, text="▣  Open folder", command=self._open_selected_folder).pack(side="left", padx=(7, 0))

    def _build_files_page(self) -> None:
        page = tk.Frame(self.pages, bg=BG)
        self.page_frames["files"] = page
        box = tk.Frame(page, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        box.pack(fill="both", expand=True)
        self.library_tree = ttk.Treeview(
            box,
            columns=("icon", "category", "type", "size", "dimensions", "date", "rating", "favorite", "hash", "error"),
            show="tree headings",
        )
        headings = {
            "#0": ("Path", "path"), "icon": ("", "category"), "category": ("Category", "category"),
            "type": ("Resolved type", "type"), "size": ("Size", "size"), "dimensions": ("Dimensions", "dimensions"),
            "date": ("Captured / modified", "date"), "rating": ("Rating", "rating"), "favorite": ("Fav", "favorite"),
            "hash": ("SHA-256", "hash"), "error": ("Error", "error"),
        }
        self.file_heading_labels = {col: label for col, (label, _sort) in headings.items()}
        for col, (label, sort_key) in headings.items():
            self.library_tree.heading(col, text=label, command=lambda key=sort_key: self._sort_all_files(key))
        widths = {"#0": 390, "icon": 38, "category": 90, "type": 190, "size": 90, "dimensions": 100,
                  "date": 150, "rating": 65, "favorite": 50, "hash": 140, "error": 170}
        for col, width in widths.items():
            self.library_tree.column(col, width=width, anchor="w" if col not in {"size", "dimensions", "icon", "rating", "favorite"} else "center")
        scroll = ttk.Scrollbar(box, orient="vertical", command=self.library_tree.yview)
        self.library_tree.configure(yscrollcommand=scroll.set)
        self.library_tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=8)
        scroll.pack(side="right", fill="y", padx=(0, 8), pady=8)
        self.file_rows_by_iid: dict[str, FileRow] = {}
        self.library_tree.bind("<Double-Button-1>", self._on_all_files_double_click)

    def _build_duplicates_page(self) -> None:
        page = tk.Frame(self.pages, bg=BG); self.page_frames["duplicates"] = page
        box = tk.Frame(page, bg=PANEL, highlightbackground=BORDER, highlightthickness=1); box.pack(fill="both", expand=True)
        head = tk.Frame(box, bg=PANEL); head.pack(fill="x", padx=10, pady=(10,5))
        tk.Label(head, text="EXACT DUPLICATES", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(side="left")
        tk.Label(head, text="SHA-256 verified · review only · no automatic deletion in Chunk 3", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 9)).pack(side="right")
        treebox = tk.Frame(box, bg=PANEL); treebox.pack(fill="both", expand=True, padx=8, pady=(0,8))
        self.dup_tree = ttk.Treeview(treebox, columns=("size","copies","wasted"), show="tree headings")
        self.dup_tree.heading("#0", text="SHA-256 / file path"); self.dup_tree.heading("size",text="File size")
        self.dup_tree.heading("copies",text="Copies"); self.dup_tree.heading("wasted",text="Duplicate bytes")
        self.dup_tree.column("#0",width=720); self.dup_tree.column("size",width=110,anchor="e")
        self.dup_tree.column("copies",width=80,anchor="center"); self.dup_tree.column("wasted",width=130,anchor="e")
        scroll = ttk.Scrollbar(treebox, orient="vertical", command=self.dup_tree.yview); self.dup_tree.configure(yscrollcommand=scroll.set)
        self.dup_tree.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")

    def _build_storage_page(self) -> None:
        page = tk.Frame(self.pages, bg=BG); self.page_frames["storage"] = page
        left = tk.Frame(page, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        right = tk.Frame(page, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        left.pack(side="left", fill="both", expand=True, padx=(0,6)); right.pack(side="left", fill="both", expand=True, padx=(6,0))

        tk.Label(left, text="STORAGE SOURCES", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=12, pady=(12,4))
        tk.Label(left, text="PicaCatalog catalogues files in place. Nothing is imported or moved.", bg=PANEL, fg=TEXT,
                 font=("DejaVu Sans", 9), wraplength=520, justify="left").pack(anchor="w", padx=12, pady=(0,10))
        addrow = tk.Frame(left, bg=PANEL); addrow.pack(fill="x", padx=12)
        self.source_entry = ttk.Entry(addrow); self.source_entry.insert(0, "/mnt/photos"); self.source_entry.pack(side="left", fill="x", expand=True)
        ttk.Button(addrow, text="Browse", command=self._browse_source).pack(side="left", padx=(7,0))
        ttk.Button(addrow, text="＋ Add", style="Accent.TButton", command=self._add_source).pack(side="left", padx=(7,0))
        listwrap = tk.Frame(left, bg=PANEL); listwrap.pack(fill="both", expand=True, padx=12, pady=10)
        self.source_list = tk.Listbox(listwrap, height=9, selectmode="extended", bg=CARD, fg=TEXT, selectbackground=ACCENT,
                                      selectforeground="white", highlightbackground=BORDER, highlightcolor=ACCENT, relief="flat", bd=0)
        srcscroll = ttk.Scrollbar(listwrap, orient="vertical", command=self.source_list.yview); self.source_list.configure(yscrollcommand=srcscroll.set)
        self.source_list.pack(side="left", fill="both", expand=True); srcscroll.pack(side="right", fill="y")
        ttk.Button(left, text="− Remove selected", command=self._remove_sources).pack(anchor="w", padx=12, pady=(0,12))

        tk.Label(right, text="SCAN SETTINGS", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=12, pady=(12,4))
        self.include_hidden_var = tk.BooleanVar(value=False)
        hidden_check = ttk.Checkbutton(right, text="Include hidden files and folders (.cache, .config, .local, etc.)",
                                       variable=self.include_hidden_var, command=self._save_scan_settings)
        hidden_check.pack(anchor="w", padx=12, pady=(6,3))
        tk.Label(right, text="Default: OFF. When off, names beginning with '.' are not indexed or hashed.", bg=PANEL, fg=MUTED,
                 font=("DejaVu Sans", 9), wraplength=520, justify="left").pack(anchor="w", padx=12, pady=(0,14))

        tk.Label(right, text="SOURCE IDENTITY / OFFLINE STATUS", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=12, pady=(4,4))
        self.source_status_var = tk.StringVar(value="No source identity records yet. Run a scan.")
        tk.Label(right, textvariable=self.source_status_var, bg=PANEL, fg=TEXT, font=("DejaVu Sans", 8),
                 wraplength=520, justify="left").pack(anchor="w", padx=12, pady=(0,12))

        tk.Label(right, text="FUTURE CONSOLIDATION TARGET", bg=PANEL, fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=12, pady=(8,4))
        targetrow = tk.Frame(right, bg=PANEL); targetrow.pack(fill="x", padx=12)
        self.target_entry = ttk.Entry(targetrow); self.target_entry.insert(0, "/mnt/master-library"); self.target_entry.pack(side="left", fill="x", expand=True)
        ttk.Button(targetrow, text="Browse", command=self._browse_target).pack(side="left", padx=(7,0))
        ttk.Button(targetrow, text="Save", command=self._save_target).pack(side="left", padx=(7,0))
        tk.Label(right, text="Target is stored for later consolidation chunks; no automatic deletion exists in Chunk 3.", bg=PANEL, fg=MUTED,
                 font=("DejaVu Sans", 9), wraplength=520, justify="left").pack(anchor="w", padx=12, pady=(5,18))

        resetbox = tk.Frame(right, bg="#111b30", highlightbackground=BORDER, highlightthickness=1); resetbox.pack(fill="x", padx=12, pady=(8,12))
        tk.Label(resetbox, text="RESET OPTIONS", bg="#111b30", fg=MUTED, font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=10, pady=(9,3))
        tk.Label(resetbox, text="Clear results keeps storage settings. Start over also removes saved sources and preferences. Neither deletes source files.",
                 bg="#111b30", fg=TEXT, font=("DejaVu Sans", 9), wraplength=500, justify="left").pack(anchor="w", padx=10, pady=(0,8))
        resetbuttons = tk.Frame(resetbox, bg="#111b30"); resetbuttons.pack(fill="x", padx=10, pady=(0,10))
        ttk.Button(resetbuttons, text="⌫ Clear results", command=self._clear_results).pack(side="left")
        ttk.Button(resetbuttons, text="⟲ Start over", style="Danger.TButton", command=self._start_over).pack(side="left", padx=(8,0))

    def _show_page(self, page: str) -> None:
        if page not in self.page_frames:
            return
        for frame in self.page_frames.values():
            frame.pack_forget()
        self.page_frames[page].pack(fill="both", expand=True)
        self.current_page = page
        titles = {"library": "Library", "files": "All files", "duplicates": "Exact duplicates", "storage": "Storage & scan settings"}
        self.page_title.set(titles.get(page, "PicaCatalog"))
        for name, btn in self.nav_buttons.items():
            selected = name == page
            btn.configure(bg=CARD if selected else SIDEBAR, fg=TEXT if selected else MUTED)

        # Chunk 3 performance rule: switching tabs is a visibility operation, not a rebuild.
        # Pages only refresh when their underlying data/filter has been marked dirty.
        if self.stats_dirty:
            self._refresh_stats()
        if page == "library":
            if self.nav_dirty:
                self._refresh_navigation()
            if self.page_dirty["library"]:
                self._refresh_media_grid(force=True)
        elif page == "files" and self.page_dirty["files"]:
            self._refresh_files_table()
        elif page == "duplicates" and self.page_dirty["duplicates"]:
            self._refresh_duplicates_table()
        elif page == "storage" and self.page_dirty["storage"]:
            self._refresh_source_status()
        self._activity(f"[INFO] Page: {titles.get(page, page)}")

    def _load_settings(self) -> None:
        self.source_list.delete(0, "end")
        for source in self._sources():
            self.source_list.insert("end", source)
        target = self.catalog.get_setting("target", "/mnt/master-library")
        self.target_entry.delete(0, "end")
        self.target_entry.insert(0, target)
        self.include_hidden_var.set(self.catalog.get_setting("include_hidden", "0") == "1")
        self._mark_catalog_dirty()
        self._refresh_stats()
        self._refresh_navigation()
        self._refresh_media_grid(force=True)
        self._refresh_source_status()

    def _sources(self) -> list[str]:
        return [s.strip() for s in self.catalog.get_setting("sources", "").split("\n") if s.strip()]

    def _save_sources(self) -> None:
        self.catalog.set_setting("sources", "\n".join(self.source_list.get(0,"end")))

    def _browse_source(self) -> None:
        chosen = choose_directory(parent=self, title="Choose a storage source", initial=self.source_entry.get().strip() or str(Path.home()))
        if chosen:
            self.source_entry.delete(0,"end"); self.source_entry.insert(0,chosen)
            self._activity(f"[INFO] Storage picker selected: {chosen}")

    def _add_source(self) -> None:
        value = self.source_entry.get().strip()
        if not value: return
        existing = set(self.source_list.get(0,"end"))
        if value not in existing: self.source_list.insert("end", value); self._save_sources()
        self._activity(f"[OK] Storage source saved: {value}")

    def _remove_sources(self) -> None:
        for idx in reversed(self.source_list.curselection()): self.source_list.delete(idx)
        self._save_sources(); self._activity("[INFO] Selected storage source(s) removed from settings.")

    def _browse_target(self) -> None:
        chosen = choose_directory(parent=self, title="Choose future consolidation target", initial=self.target_entry.get().strip() or str(Path.home()))
        if chosen:
            self.target_entry.delete(0,"end"); self.target_entry.insert(0,chosen)
            self._activity(f"[INFO] Target picker selected: {chosen}")

    def _save_target(self) -> None:
        self.catalog.set_setting("target", self.target_entry.get().strip()); self._activity("[OK] Future target setting saved.")

    def _save_scan_settings(self) -> None:
        self.catalog.set_setting("include_hidden", "1" if self.include_hidden_var.get() else "0")
        state = "included" if self.include_hidden_var.get() else "excluded"
        self.hidden_stat.set("Included" if self.include_hidden_var.get() else "Excluded")
        self._activity(f"[INFO] Hidden files/folders will be {state} on the next scan.")

    def _toggle_hidden_paths(self) -> None:
        self.include_hidden_var.set(not self.include_hidden_var.get())
        self._save_scan_settings()

    def _start_scan(self) -> None:
        if self.scan_thread and self.scan_thread.is_alive():
            messagebox.showinfo("Scan already running", "PicaCatalog is already scanning.", parent=self); return
        sources = self._sources()
        if not sources:
            self._show_page("storage")
            messagebox.showwarning("No storage sources", "Add at least one storage source first.", parent=self); return
        include_hidden = self.include_hidden_var.get()
        self.scan_button.configure(state="disabled"); self.progress.start(12); self.status_var.set("Scanning…")
        self._activity(f"[INFO] Scan started. Hidden paths: {'included' if include_hidden else 'excluded'}.")

        def worker() -> None:
            try:
                scan_sources(self.catalog, sources, progress=lambda ev: self.events.put(ev), logger=self.logger,
                             build_thumbnails=True, include_hidden=include_hidden)
            except Exception as exc:
                self.logger.exception("Scan failed"); self.events.put({"phase":"fatal","message":str(exc)})
        self.scan_thread = threading.Thread(target=worker, daemon=True); self.scan_thread.start()

    def _poll_events(self) -> None:
        try:
            while True:
                ev = self.events.get_nowait(); phase = ev.get("phase"); msg = ev.get("message", "")
                if msg and phase in {"source","source-offline","index","hash-start","hash","error"}: self.status_var.set(msg)
                if msg and phase in {"source","source-offline","error","hash-start"}: self._activity(f"[{'WARN' if phase in {'error','source-offline'} else 'INFO'}] {msg}")
                if phase == "done":
                    summary = ev.get("summary"); self.progress.stop(); self.scan_button.configure(state="normal")
                    if summary:
                        self.status_var.set(f"Done · {summary.indexed:,} indexed · {summary.errors} errors")
                        self._activity(f"[OK] Scan complete: {summary.indexed:,} files, {summary.types_resolved:,} types resolved, "
                                       f"{summary.hidden_skipped:,} hidden entries skipped, {summary.sources_online} sources online, {summary.sources_offline} offline, {summary.errors} errors.")
                    self._refresh_all()
                elif phase == "fatal":
                    self.progress.stop(); self.scan_button.configure(state="normal"); self.status_var.set("Scan failed")
                    self._activity(f"[ERROR] {msg}"); messagebox.showerror("Scan failed", msg, parent=self)
        except queue.Empty: pass
        self.after(100, self._poll_events)

    def _clear_thumbnail_cache(self) -> None:
        root = thumbnail_dir()
        if root.exists(): shutil.rmtree(root, ignore_errors=True)
        root.mkdir(parents=True, exist_ok=True)

    def _clear_results(self) -> None:
        if self.scan_thread and self.scan_thread.is_alive():
            messagebox.showwarning("Scan running", "Wait for the current scan to finish before clearing results.", parent=self); return
        if not messagebox.askyesno("Clear scan results?",
            "Clear all indexed results and cached thumbnails?\n\nSaved storage sources and scan settings will be kept.\nSource files will NOT be deleted or changed.", parent=self): return
        count = self.catalog.clear_results(); self._clear_thumbnail_cache(); self.current_media = None
        self._activity(f"[OK] Cleared {count:,} catalogue records and thumbnail cache. Storage settings were kept.")
        self.status_var.set("Results cleared"); self._refresh_all()

    def _start_over(self) -> None:
        if self.scan_thread and self.scan_thread.is_alive():
            messagebox.showwarning("Scan running", "Wait for the current scan to finish before starting over.", parent=self); return
        if not messagebox.askyesno("Start PicaCatalog over?",
            "This resets PicaCatalog's local catalogue, thumbnail cache, saved storage sources, target and scan preferences.\n\n"
            "Your actual photos, videos and other source files will NOT be deleted, moved or changed.\n\nContinue?", parent=self): return
        count = self.catalog.start_over(); self._clear_thumbnail_cache(); self.current_media = None
        self.source_list.delete(0,"end"); self.source_entry.delete(0,"end"); self.source_entry.insert(0,"/mnt/photos")
        self.target_entry.delete(0,"end"); self.target_entry.insert(0,"/mnt/master-library"); self.include_hidden_var.set(False)
        self._activity(f"[OK] Start over complete. Removed {count:,} local catalogue records and reset settings.")
        self.status_var.set("Reset complete"); self._refresh_all(); self._show_page("storage")

    def _mark_catalog_dirty(self) -> None:
        for key in self.page_dirty:
            self.page_dirty[key] = True
        self.nav_dirty = True
        self.stats_dirty = True
        self.media_grid_filter_key = None

    def _refresh_all(self) -> None:
        self._mark_catalog_dirty()
        self._refresh_stats()
        if self.current_page == "library":
            self._refresh_navigation()
            self._refresh_media_grid(force=True)
        elif self.current_page == "files":
            self._refresh_files_table()
        elif self.current_page == "duplicates":
            self._refresh_duplicates_table()
        elif self.current_page == "storage":
            self._refresh_source_status()

    def _refresh_stats(self) -> None:
        counts = self.catalog.media_counts()
        groups = self.catalog.duplicate_groups()
        self.files_stat.set(f"{self.catalog.count_files():,}")
        self.photos_stat.set(f"{counts.get('image', 0):,} / {counts.get('video', 0):,}")
        self.dups_stat.set(f"{len(groups):,}")
        self.hidden_stat.set("Included" if self.include_hidden_var.get() else "Excluded")
        self.stats_dirty = False

    def _refresh_navigation(self) -> None:
        if not hasattr(self, "nav_tree"):
            return
        self.nav_tree.delete(*self.nav_tree.get_children())
        self.nav_filters.clear()
        counts = self.catalog.media_counts()
        all_id = self.nav_tree.insert("", "end", text=f"▦  All media ({counts.get('image',0)+counts.get('video',0):,})", open=True)
        self.nav_filters[all_id] = ("all", None)
        photo_id = self.nav_tree.insert("", "end", text=f"▧  Photos ({counts.get('image',0):,})")
        self.nav_filters[photo_id] = ("kind", "image")
        video_id = self.nav_tree.insert("", "end", text=f"▶  Videos ({counts.get('video',0):,})")
        self.nav_filters[video_id] = ("kind", "video")
        fav_id = self.nav_tree.insert("", "end", text=f"★  Favourites ({self.catalog.favorite_count():,})")
        self.nav_filters[fav_id] = ("favorite", True)

        albums_root = self.nav_tree.insert("", "end", text="▣  Albums", open=True)
        for album_id, name, n in self.catalog.albums_with_counts():
            iid = self.nav_tree.insert(albums_root, "end", text=f"{name} ({n:,})")
            self.nav_filters[iid] = ("album", album_id)

        tags_root = self.nav_tree.insert("", "end", text="⌗  Tags", open=False)
        for tag, n in self.catalog.tag_counts().items():
            iid = self.nav_tree.insert(tags_root, "end", text=f"{tag} ({n:,})")
            self.nav_filters[iid] = ("tag", tag)

        folders = self.nav_tree.insert("", "end", text="▣  Folders", open=True)
        for folder, n in self.catalog.folder_counts().items():
            iid = self.nav_tree.insert(folders, "end", text=f"{Path(folder).name or folder} ({n:,})")
            self.nav_filters[iid] = ("folder", folder)

        timeline = self.nav_tree.insert("", "end", text="◷  Timeline", open=True)
        years: dict[str, str] = {}
        for ym, n in self.catalog.date_counts().items():
            year = ym[:4]
            if year not in years:
                years[year] = self.nav_tree.insert(timeline, "end", text=year, open=False)
            iid = self.nav_tree.insert(years[year], "end", text=f"{ym} ({n:,})")
            self.nav_filters[iid] = ("date", ym)

        selected = next((iid for iid, filt in self.nav_filters.items() if filt == self.current_filter), None)
        if not selected:
            self.current_filter = ("all", None)
            selected = all_id
        self.nav_tree.selection_set(selected)
        self.nav_tree.see(selected)
        self.nav_dirty = False
        self._refresh_album_choices()

    def _on_nav_select(self, _event: object = None) -> None:
        sel = self.nav_tree.selection()
        if sel and sel[0] in self.nav_filters:
            new_filter = self.nav_filters[sel[0]]
            if new_filter != self.current_filter:
                self.current_filter = new_filter
                self.page_dirty["library"] = True
                self._refresh_media_grid(force=True)

    def _filtered_media(self) -> list[FileRow]:
        mode, value = self.current_filter
        kwargs: dict[str, object] = {"limit": 240, "query": self.search_query}
        if mode == "folder":
            kwargs["folder_prefix"] = str(value)
        elif mode == "date":
            kwargs["date_prefix"] = str(value)
        elif mode == "kind":
            kwargs["media_kind"] = str(value)
        elif mode == "favorite":
            kwargs["favorite"] = True
        elif mode == "tag":
            kwargs["tag"] = str(value)
        elif mode == "album":
            kwargs["album_id"] = int(value)
        return self.catalog.media_files(**kwargs)

    def _refresh_media_grid(self, force: bool = False) -> None:
        if not hasattr(self, "media_grid"):
            return
        filter_key = (self.current_filter[0], self.current_filter[1], self.search_query)
        if not force and not self.page_dirty["library"] and self.media_grid_filter_key == filter_key:
            return

        for child in self.media_grid.winfo_children():
            child.destroy()
        self.thumb_refs.clear()
        rows = self._filtered_media()
        mode, value = self.current_filter
        heading = {
            "all": "All media", "kind": "Photos" if value == "image" else "Videos",
            "folder": str(value or "Folder"), "date": str(value or "Timeline"),
            "favorite": "Favourites", "tag": f"Tag: {value}", "album": self._album_name_for_id(value),
        }.get(mode, "Media")
        if self.search_query:
            heading = f"{heading} · search: {self.search_query}"
        self.media_heading.set(heading)
        self.media_count_var.set(f"{len(rows):,} shown" + (" · display limit 240" if len(rows) >= 240 else ""))
        columns = 4
        for c in range(columns):
            self.media_grid.columnconfigure(c, weight=1)

        for index, row in enumerate(rows):
            r, c = divmod(index, columns)
            card = tk.Frame(self.media_grid, bg=CARD, highlightbackground=BORDER, highlightthickness=1, cursor="hand2")
            card.grid(row=r, column=c, padx=5, pady=5, sticky="nsew")
            try:
                thumb = ensure_thumbnail(Path(row.path), row.media_kind, thumbnail_dir())
                with Image.open(thumb) as im:
                    photo = ImageTk.PhotoImage(im.copy())
            except Exception:
                photo = None
            if photo is not None:
                image_label = tk.Label(card, image=photo, bg="#0b1324", anchor="center", cursor="hand2")
                self.thumb_refs.append(photo)
            else:
                image_label = tk.Label(card, text=CATEGORY_ICONS.get(row.file_category, "•"), bg="#0b1324", fg=ACCENT_HOVER,
                                       font=("DejaVu Sans", 28), height=5, cursor="hand2")
            image_label.pack(fill="both", expand=True, padx=5, pady=(5, 3))
            title = ("★ " if row.favorite else "") + Path(row.path).name
            tk.Label(card, text=title, bg=CARD, fg=TEXT, anchor="w", font=("DejaVu Sans", 9, "bold")).pack(fill="x", padx=8, pady=(3, 0))
            secondary = row.capture_time[:10] if row.capture_time else self._human_bytes(row.size)
            stars = f" · {'★' * row.rating}" if row.rating else ""
            tk.Label(card, text=f"{CATEGORY_ICONS.get(row.file_category,'•')} {row.file_type or row.media_kind} · {secondary}{stars}",
                     bg=CARD, fg=MUTED, anchor="w", font=("DejaVu Sans", 8)).pack(fill="x", padx=8, pady=(2, 7))
            for widget in [card, *card.winfo_children()]:
                widget.bind("<Button-1>", lambda _e, rr=row: self._select_media(rr))
                widget.bind("<Double-Button-1>", lambda _e, rr=row: self._open_media(rr))

        self.media_grid.update_idletasks()
        self.media_canvas.configure(scrollregion=self.media_canvas.bbox("all"))
        self.media_canvas.yview_moveto(0)
        self.media_grid_filter_key = filter_key
        self.page_dirty["library"] = False

    def _select_media(self, row: FileRow) -> None:
        self.current_media = row
        try:
            thumb = ensure_thumbnail(Path(row.path), row.media_kind, thumbnail_dir())
            with Image.open(thumb) as im:
                enlarged = im.copy()
                enlarged.thumbnail((320, 215), Image.Resampling.LANCZOS)
                self.preview_ref = ImageTk.PhotoImage(enlarged)
            self.preview_label.configure(image=self.preview_ref, text="", height=0)
        except Exception:
            self.preview_ref = None
            self.preview_label.configure(image="", text="Preview unavailable / source offline", height=9)

        tags = self.catalog.tags_for_file(row.path)
        albums = self.catalog.albums_for_file(row.path)
        lines = [
            f"Name: {Path(row.path).name}", f"Category: {row.file_category}", f"Resolved type: {row.file_type or 'Unknown'}",
            f"Path: {row.path}", f"Source: {row.source_root}", f"Size: {self._human_bytes(row.size)}",
            f"Favourite: {'Yes' if row.favorite else 'No'}", f"Rating: {row.rating}/5",
        ]
        if row.caption:
            lines.append(f"Caption: {row.caption}")
        if tags:
            lines.append("Tags: " + ", ".join(tags))
        if albums:
            lines.append("Albums: " + ", ".join(name for _id, name in albums))
        if row.width and row.height:
            lines.append(f"Dimensions: {row.width} × {row.height}")
        if row.duration_seconds is not None:
            lines.append(f"Duration: {self._duration(row.duration_seconds)}")
        if row.capture_time:
            lines.append(f"Captured / modified: {row.capture_time}")
        if row.camera_make or row.camera_model:
            lines.append(f"Camera: {' '.join(v for v in [row.camera_make, row.camera_model] if v)}")
        if row.mime_type:
            lines.append(f"MIME: {row.mime_type}")
        if row.media_error:
            lines.append(f"Media warning: {row.media_error}")
        if row.sha256:
            lines.append(f"SHA-256: {row.sha256}")
        self.details_text.configure(state="normal")
        self.details_text.delete("1.0", "end")
        self.details_text.insert("1.0", "\n".join(lines))
        self.details_text.configure(state="disabled")
        self.favorite_var.set(bool(row.favorite))
        self.rating_var.set(str(row.rating))
        self.caption_var.set(row.caption or "")
        self.tags_var.set(", ".join(tags))
        self._refresh_album_choices()

    def _open_selected_media(self) -> None:
        if self.current_media: self._open_media(self.current_media)

    def _open_media(self,row:FileRow) -> None:
        if row.media_kind=="image": self._show_image_viewer(Path(row.path))
        else: self._xdg_open(Path(row.path))

    def _show_image_viewer(self,path:Path) -> None:
        try:
            with Image.open(path) as opened:
                image=ImageOps.exif_transpose(opened).convert("RGB")
                image.thumbnail((max(800,self.winfo_screenwidth()-160),max(600,self.winfo_screenheight()-180)),Image.Resampling.LANCZOS)
                photo=ImageTk.PhotoImage(image)
        except Exception as exc: messagebox.showerror("Unable to open image",f"{path}\n\n{exc}",parent=self); return
        viewer=tk.Toplevel(self); viewer.title(path.name); viewer.configure(bg=BG)
        viewer.geometry(f"{min(photo.width()+40,self.winfo_screenwidth()-80)}x{min(photo.height()+80,self.winfo_screenheight()-100)}")
        label=tk.Label(viewer,image=photo,bg=BG,anchor="center"); label.image=photo; label.pack(fill="both",expand=True,padx=10,pady=10)
        tk.Label(viewer,text=str(path),bg=BG,fg=MUTED).pack(fill="x",padx=10,pady=(0,10))

    def _open_selected_folder(self) -> None:
        if self.current_media: self._xdg_open(Path(self.current_media.path).parent)

    def _xdg_open(self,path:Path) -> None:
        try: subprocess.Popen(["xdg-open",str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        except OSError as exc: messagebox.showerror("Unable to open",f"{path}\n\n{exc}",parent=self)

    def _refresh_tables(self) -> None:
        # Compatibility helper used by older call sites/tests; refreshes only dirty tables.
        if self.page_dirty.get("files", True):
            self._refresh_files_table()
        if self.page_dirty.get("duplicates", True):
            self._refresh_duplicates_table()

    def _on_all_files_double_click(self, _event: object = None) -> None:
        iid = self.library_tree.focus()
        row = self.file_rows_by_iid.get(iid)
        if row is None:
            selected = self.library_tree.selection()
            row = self.file_rows_by_iid.get(selected[0]) if selected else None
        if row is not None:
            self._activity(f"[INFO] Opening from All files: {row.path}")
            self._open_media(row)

    def _apply_search(self) -> None:
        query = self.search_var.get().strip()
        if query == self.search_query:
            return
        self.search_query = query
        self.page_dirty["library"] = True
        self.page_dirty["files"] = True
        self.media_grid_filter_key = None
        self.search_hint.set(f"Filtering locally for: {query}" if query else "Search path, type, caption or tags")
        self._activity(f"[INFO] Search filter: {query or 'cleared'}")
        if self.current_page == "library":
            self._refresh_media_grid(force=True)
        elif self.current_page == "files":
            self._refresh_files_table()

    def _clear_search(self) -> None:
        self.search_var.set("")
        self._apply_search()

    def _sort_all_files(self, sort_key: str) -> None:
        if sort_key == self.file_sort_column:
            self.file_sort_desc = not self.file_sort_desc
        else:
            self.file_sort_column = sort_key
            self.file_sort_desc = False
        self.page_dirty["files"] = True
        self._refresh_files_table()

    def _update_file_heading_arrows(self) -> None:
        mapping = {
            "#0": "path", "icon": "category", "category": "category", "type": "type", "size": "size",
            "dimensions": "dimensions", "date": "date", "rating": "rating", "favorite": "favorite",
            "hash": "hash", "error": "error",
        }
        for col, key in mapping.items():
            base = self.file_heading_labels.get(col, "")
            arrow = " ▼" if self.file_sort_desc else " ▲"
            self.library_tree.heading(col, text=base + (arrow if key == self.file_sort_column else ""))

    def _refresh_files_table(self) -> None:
        if not hasattr(self, "library_tree"):
            return
        self.library_tree.delete(*self.library_tree.get_children())
        self.file_rows_by_iid.clear()
        rows = self.catalog.all_files(
            limit=5000, sort_by=self.file_sort_column, descending=self.file_sort_desc, query=self.search_query,
        )
        for row in rows:
            short_hash = row.sha256[:18] + "…" if row.sha256 else ""
            dims = f"{row.width}×{row.height}" if row.width and row.height else ""
            error = row.last_error or row.media_error or ""
            icon = CATEGORY_ICONS.get(row.file_category, "•")
            iid = self.library_tree.insert(
                "", "end", text=row.path,
                values=(icon, row.file_category, row.file_type or "Unknown", self._human_bytes(row.size), dims,
                        row.capture_time or "", row.rating, "★" if row.favorite else "", short_hash, error),
            )
            self.file_rows_by_iid[iid] = row
        self._update_file_heading_arrows()
        suffix = f" · search '{self.search_query}'" if self.search_query else ""
        self.status_var.set(f"All files: {len(rows):,} rows{suffix}")
        self.page_dirty["files"] = False

    def _refresh_duplicates_table(self) -> None:
        if not hasattr(self, "dup_tree"):
            return
        self.dup_tree.delete(*self.dup_tree.get_children())
        groups = self.catalog.duplicate_groups()
        total_waste = 0
        for digest, size, paths in groups:
            wasted = size * (len(paths) - 1)
            total_waste += wasted
            parent = self.dup_tree.insert("", "end", text=digest,
                                          values=(self._human_bytes(size), len(paths), self._human_bytes(wasted)), open=False)
            for path in paths:
                self.dup_tree.insert(parent, "end", text=path, values=("", "", ""))
        self.status_var.set(f"Duplicates: {len(groups):,} groups · {self._human_bytes(total_waste)} reclaimable if reviewed")
        self.page_dirty["duplicates"] = False

    def _save_selected_metadata(self) -> None:
        if not self.current_media:
            messagebox.showinfo("Nothing selected", "Select a photo or video first.", parent=self)
            return
        tags = [item.strip() for item in self.tags_var.get().split(",") if item.strip()]
        self.catalog.set_annotations(
            self.current_media.path,
            rating=int(self.rating_var.get() or 0), favorite=self.favorite_var.get(),
            caption=self.caption_var.get(), tags=tags,
        )
        refreshed = self.catalog.file_by_path(self.current_media.path)
        if refreshed:
            self.current_media = refreshed
        self._activity(f"[OK] Saved metadata: {self.current_media.path}")
        self.page_dirty["library"] = True
        self.page_dirty["files"] = True
        self.nav_dirty = True
        self.stats_dirty = True
        self._refresh_navigation()
        self._refresh_media_grid(force=True)
        if refreshed:
            self._select_media(refreshed)

    def _create_album(self) -> None:
        name = simpledialog.askstring("New album", "Album name:", parent=self)
        if not name:
            return
        try:
            album_id = self.catalog.create_album(name)
        except ValueError as exc:
            messagebox.showerror("Album", str(exc), parent=self)
            return
        self._activity(f"[OK] Album ready: {name.strip()}")
        self.nav_dirty = True
        self.page_dirty["library"] = True
        self._refresh_navigation()
        self.album_var.set(self._album_name_for_id(album_id))

    def _add_selected_to_album(self) -> None:
        if not self.current_media:
            messagebox.showinfo("Nothing selected", "Select a photo or video first.", parent=self)
            return
        name = self.album_var.get().strip()
        if not name:
            messagebox.showinfo("Choose an album", "Choose an album or create one with +.", parent=self)
            return
        album_id = next((aid for aid, aname, _n in self.catalog.albums_with_counts() if aname == name), None)
        if album_id is None:
            return
        if self.catalog.add_file_to_album(self.current_media.path, album_id):
            self._activity(f"[OK] Added {Path(self.current_media.path).name} to album {name}")
            self.nav_dirty = True
            self.page_dirty["library"] = True
            self._refresh_navigation()
            self._select_media(self.current_media)

    def _refresh_album_choices(self) -> None:
        if not hasattr(self, "album_combo"):
            return
        names = [name for _aid, name, _n in self.catalog.albums_with_counts()]
        current = self.album_var.get()
        self.album_combo.configure(values=names)
        if current not in names:
            self.album_var.set(names[0] if names else "")

    def _album_name_for_id(self, album_id: object) -> str:
        try:
            wanted = int(album_id)
        except (TypeError, ValueError):
            return "Album"
        for aid, name, _n in self.catalog.albums_with_counts():
            if aid == wanted:
                return f"Album: {name}"
        return "Album"

    def _refresh_source_status(self) -> None:
        if not hasattr(self, "source_status_var"):
            return
        records = self.catalog.source_records()
        if not records:
            self.source_status_var.set("No source identity records yet. Run a scan.")
        else:
            lines = []
            for src in records[:8]:
                state = "● online" if src.online else "○ offline"
                label = src.label or Path(src.configured_path).name or src.configured_path
                uuid_text = f" · UUID {src.filesystem_uuid}" if src.filesystem_uuid else ""
                path = src.current_path or src.configured_path
                lines.append(f"{state} · {label}{uuid_text}\n  {path}")
            if len(records) > 8:
                lines.append(f"…and {len(records)-8} more")
            self.source_status_var.set("\n".join(lines))
        self.page_dirty["storage"] = False

    def _activity(self,message:str) -> None:
        text = message.rstrip()
        upper = text.upper()
        if upper.startswith("[ERROR]"):
            self.logger.error("ACTIVITY %s", text)
        elif upper.startswith("[WARN]"):
            self.logger.warning("ACTIVITY %s", text)
        else:
            self.logger.info("ACTIVITY %s", text)
        if not hasattr(self,"activity_text"):
            return
        self.activity_text.configure(state="normal")
        self.activity_text.insert("end",text+"\n")
        self.activity_text.see("end")
        self.activity_text.configure(state="disabled")

    def _sync_media_scrollregion(self,_event:object=None) -> None:
        self.media_canvas.configure(scrollregion=self.media_canvas.bbox("all"))

    def _resize_media_window(self,event:tk.Event) -> None:
        self.media_canvas.itemconfigure(self.media_window,width=event.width)

    def _mousewheel_media(self, event: tk.Event) -> str | None:
        if self.current_page != "library" or not hasattr(self, "media_canvas"):
            return None
        # Only capture the wheel while the pointer is physically over the thumbnail canvas.
        try:
            px, py = self.winfo_pointerxy()
            left, top = self.media_canvas.winfo_rootx(), self.media_canvas.winfo_rooty()
            right = left + self.media_canvas.winfo_width()
            bottom = top + self.media_canvas.winfo_height()
            if not (left <= px <= right and top <= py <= bottom):
                return None
        except tk.TclError:
            return None

        if getattr(event, "num", None) == 4:
            units = -3
        elif getattr(event, "num", None) == 5:
            units = 3
        else:
            delta = getattr(event, "delta", 0)
            if delta == 0:
                return None
            units = -3 if delta > 0 else 3
        self.media_canvas.yview_scroll(units, "units")
        return "break"

    @staticmethod
    def _human_bytes(value:int) -> str:
        n=float(value)
        for unit in ["B","KiB","MiB","GiB","TiB","PiB"]:
            if n<1024 or unit=="PiB": return f"{n:.0f} {unit}" if unit=="B" else f"{n:.1f} {unit}"
            n/=1024
        return f"{value} B"

    @staticmethod
    def _duration(seconds:float) -> str:
        total=int(round(seconds)); h,rem=divmod(total,3600); m,s=divmod(rem,60)
        return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
