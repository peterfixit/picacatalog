from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

from .media import MediaMetadata

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY,
    path TEXT NOT NULL UNIQUE,
    source_root TEXT NOT NULL,
    source_id TEXT,
    parent_path TEXT,
    size INTEGER NOT NULL,
    mtime_ns INTEGER NOT NULL,
    sha256 TEXT,
    scan_token TEXT NOT NULL,
    last_error TEXT,
    media_kind TEXT NOT NULL DEFAULT 'other',
    mime_type TEXT,
    file_category TEXT NOT NULL DEFAULT 'other',
    file_type TEXT,
    width INTEGER,
    height INTEGER,
    duration_seconds REAL,
    capture_time TEXT,
    camera_make TEXT,
    camera_model TEXT,
    metadata_json TEXT,
    media_error TEXT,
    rating INTEGER NOT NULL DEFAULT 0,
    favorite INTEGER NOT NULL DEFAULT 0,
    caption TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sources (
    id TEXT PRIMARY KEY,
    identity_key TEXT NOT NULL UNIQUE,
    configured_path TEXT NOT NULL,
    current_path TEXT,
    label TEXT,
    filesystem_uuid TEXT,
    device_source TEXT,
    online INTEGER NOT NULL DEFAULT 0,
    last_seen TEXT
);
CREATE TABLE IF NOT EXISTS tags (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL COLLATE NOCASE UNIQUE
);
CREATE TABLE IF NOT EXISTS file_tags (
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY(file_id, tag_id)
);
CREATE TABLE IF NOT EXISTS albums (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL COLLATE NOCASE UNIQUE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS album_files (
    album_id INTEGER NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    position INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(album_id, file_id)
);
CREATE INDEX IF NOT EXISTS idx_files_size ON files(size);
CREATE INDEX IF NOT EXISTS idx_files_sha256 ON files(sha256);
CREATE INDEX IF NOT EXISTS idx_files_source_root ON files(source_root);
CREATE INDEX IF NOT EXISTS idx_file_tags_tag ON file_tags(tag_id);
CREATE INDEX IF NOT EXISTS idx_album_files_album ON album_files(album_id);
"""

MIGRATION_COLUMNS = {
    "media_kind": "TEXT NOT NULL DEFAULT 'other'", "mime_type": "TEXT",
    "file_category": "TEXT NOT NULL DEFAULT 'other'", "file_type": "TEXT",
    "width": "INTEGER", "height": "INTEGER", "duration_seconds": "REAL",
    "capture_time": "TEXT", "camera_make": "TEXT", "camera_model": "TEXT",
    "metadata_json": "TEXT", "media_error": "TEXT",
    "source_id": "TEXT", "parent_path": "TEXT",
    "rating": "INTEGER NOT NULL DEFAULT 0", "favorite": "INTEGER NOT NULL DEFAULT 0",
    "caption": "TEXT NOT NULL DEFAULT ''",
}


@dataclass(frozen=True)
class FileRow:
    path: str
    source_root: str
    size: int
    mtime_ns: int
    sha256: str | None
    last_error: str | None
    media_kind: str = "other"
    mime_type: str | None = None
    file_category: str = "other"
    file_type: str | None = None
    width: int | None = None
    height: int | None = None
    duration_seconds: float | None = None
    capture_time: str | None = None
    camera_make: str | None = None
    camera_model: str | None = None
    metadata_json: str | None = None
    media_error: str | None = None
    rating: int = 0
    favorite: int = 0
    caption: str = ""
    source_id: str | None = None
    parent_path: str | None = None


@dataclass(frozen=True)
class SourceRow:
    id: str
    identity_key: str
    configured_path: str
    current_path: str | None
    label: str | None
    filesystem_uuid: str | None
    device_source: str | None
    online: int
    last_seen: str | None


_SELECT = """path, source_root, size, mtime_ns, sha256, last_error,
media_kind, mime_type, file_category, file_type, width, height, duration_seconds, capture_time,
camera_make, camera_model, metadata_json, media_error, rating, favorite, caption, source_id, parent_path"""

_SORT_EXPRESSIONS = {
    "path": "path COLLATE NOCASE",
    "category": "file_category COLLATE NOCASE",
    "type": "COALESCE(file_type,'') COLLATE NOCASE",
    "size": "size",
    "dimensions": "COALESCE(width,0) * COALESCE(height,0)",
    "date": "COALESCE(capture_time,'')",
    "hash": "COALESCE(sha256,'')",
    "error": "COALESCE(last_error, media_error, '') COLLATE NOCASE",
    "rating": "rating",
    "favorite": "favorite",
}


class Catalog:
    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=30000")
        con.execute("PRAGMA foreign_keys=ON")
        return con

    @contextmanager
    def _connection(self):
        con = self._connect()
        try:
            with con:
                yield con
        finally:
            con.close()

    def _init_db(self) -> None:
        with self._connection() as con:
            con.executescript(SCHEMA)
            columns = {row["name"] for row in con.execute("PRAGMA table_info(files)")}
            for name, definition in MIGRATION_COLUMNS.items():
                if name not in columns:
                    con.execute(f"ALTER TABLE files ADD COLUMN {name} {definition}")
            con.execute("CREATE INDEX IF NOT EXISTS idx_files_media_kind ON files(media_kind)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_files_capture_time ON files(capture_time)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_files_category ON files(file_category)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_files_rating ON files(rating)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_files_favorite ON files(favorite)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_files_source_id ON files(source_id)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_files_parent_path ON files(parent_path)")

    def set_setting(self, key: str, value: str) -> None:
        with self._lock, self._connection() as con:
            con.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )

    def get_setting(self, key: str, default: str = "") -> str:
        with self._connection() as con:
            row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
            return row["value"] if row else default

    def all_settings(self) -> dict[str, str]:
        with self._connection() as con:
            return {row["key"]: row["value"] for row in con.execute("SELECT key,value FROM settings")}

    def clear_results(self) -> int:
        """Clear catalogue/media metadata while preserving storage/settings."""
        with self._lock, self._connection() as con:
            count = int(con.execute("SELECT COUNT(*) FROM files").fetchone()[0])
            con.execute("DELETE FROM files")
            con.execute("DELETE FROM albums")
            con.execute("DELETE FROM tags")
            return count

    def start_over(self) -> int:
        """Clear local catalogue, source identities and all user settings. Never touches source files."""
        with self._lock, self._connection() as con:
            count = int(con.execute("SELECT COUNT(*) FROM files").fetchone()[0])
            con.execute("DELETE FROM files")
            con.execute("DELETE FROM albums")
            con.execute("DELETE FROM tags")
            con.execute("DELETE FROM sources")
            con.execute("DELETE FROM settings")
            return count

    # ---------- source identity ----------
    def register_source(
        self, *, source_id: str, identity_key: str, configured_path: str, current_path: str,
        label: str | None = None, filesystem_uuid: str | None = None, device_source: str | None = None,
    ) -> str | None:
        """Register a source and return its previous current path, if any.

        The stable source id allows a removable filesystem/folder to be recognized when its mount path changes.
        """
        with self._lock, self._connection() as con:
            old = con.execute("SELECT current_path FROM sources WHERE id=?", (source_id,)).fetchone()
            previous = old["current_path"] if old else None
            con.execute(
                """INSERT INTO sources(id,identity_key,configured_path,current_path,label,filesystem_uuid,device_source,online,last_seen)
                   VALUES(?,?,?,?,?,?,?,1,CURRENT_TIMESTAMP)
                   ON CONFLICT(id) DO UPDATE SET identity_key=excluded.identity_key, configured_path=excluded.configured_path,
                   current_path=excluded.current_path, label=excluded.label, filesystem_uuid=excluded.filesystem_uuid,
                   device_source=excluded.device_source, online=1, last_seen=CURRENT_TIMESTAMP""",
                (source_id, identity_key, configured_path, current_path, label, filesystem_uuid, device_source),
            )
            if previous and previous != current_path:
                prefix = previous.rstrip("/") + "/"
                rows = con.execute("SELECT id,path FROM files WHERE source_id=?", (source_id,)).fetchall()
                for row in rows:
                    old_path = row["path"]
                    if old_path == previous:
                        new_path = current_path
                    elif old_path.startswith(prefix):
                        new_path = current_path.rstrip("/") + "/" + old_path[len(prefix):]
                    else:
                        continue
                    # If a stale row was already indexed at the new path, keep the stable-source row.
                    con.execute("DELETE FROM files WHERE path=? AND id<>?", (new_path, row["id"]))
                    con.execute(
                        "UPDATE files SET path=?, source_root=?, parent_path=? WHERE id=?",
                        (new_path, current_path, str(Path(new_path).parent), row["id"]),
                    )
                con.execute("UPDATE files SET source_root=? WHERE source_id=?", (current_path, source_id))
            return previous

    def mark_source_offline_by_path(self, configured_path: str) -> None:
        with self._lock, self._connection() as con:
            con.execute(
                "UPDATE sources SET online=0 WHERE configured_path=? OR current_path=?",
                (configured_path, configured_path),
            )

    def source_records(self) -> list[SourceRow]:
        with self._connection() as con:
            return [SourceRow(**dict(row)) for row in con.execute(
                "SELECT id,identity_key,configured_path,current_path,label,filesystem_uuid,device_source,online,last_seen "
                "FROM sources ORDER BY online DESC, COALESCE(label,configured_path) COLLATE NOCASE"
            )]

    # ---------- file indexing ----------
    def upsert_file(
        self, *, path: str, source_root: str, size: int, mtime_ns: int, scan_token: str,
        source_id: str | None = None, parent_path: str | None = None, last_error: str | None = None,
    ) -> None:
        with self._lock, self._connection() as con:
            existing = con.execute("SELECT size,mtime_ns FROM files WHERE path=?", (path,)).fetchone()
            parent_path = parent_path or str(Path(path).parent)
            if existing is None:
                con.execute(
                    "INSERT INTO files(path,source_root,source_id,parent_path,size,mtime_ns,scan_token,last_error) VALUES(?,?,?,?,?,?,?,?)",
                    (path, source_root, source_id, parent_path, size, mtime_ns, scan_token, last_error),
                )
                return
            unchanged = existing["size"] == size and existing["mtime_ns"] == mtime_ns
            if unchanged:
                con.execute(
                    "UPDATE files SET source_root=?,source_id=?,parent_path=?,scan_token=?,last_error=?,updated_at=CURRENT_TIMESTAMP WHERE path=?",
                    (source_root, source_id, parent_path, scan_token, last_error, path),
                )
            else:
                # User metadata (rating/favorite/caption/tags/albums) intentionally survives content changes at the same path.
                con.execute(
                    """UPDATE files SET source_root=?,source_id=?,parent_path=?,size=?,mtime_ns=?,sha256=NULL,scan_token=?,last_error=?,
                    media_kind='other',mime_type=NULL,file_category='other',file_type=NULL,width=NULL,height=NULL,
                    duration_seconds=NULL,capture_time=NULL,camera_make=NULL,camera_model=NULL,metadata_json=NULL,
                    media_error=NULL,updated_at=CURRENT_TIMESTAMP WHERE path=?""",
                    (source_root, source_id, parent_path, size, mtime_ns, scan_token, last_error, path),
                )

    def set_file_type(self, path: str, category: str, label: str, mime_type: str | None) -> None:
        with self._lock, self._connection() as con:
            con.execute(
                "UPDATE files SET file_category=?,file_type=?,mime_type=COALESCE(?,mime_type),updated_at=CURRENT_TIMESTAMP WHERE path=?",
                (category, label, mime_type, path),
            )

    def type_needs_refresh(self, path: str) -> bool:
        with self._connection() as con:
            row = con.execute("SELECT file_type FROM files WHERE path=?", (path,)).fetchone()
            return row is None or not row["file_type"]

    def mark_error(self, path: str, message: str) -> None:
        with self._lock, self._connection() as con:
            con.execute("UPDATE files SET last_error=? WHERE path=?", (message, path))

    def set_hash(self, path: str, sha256: str) -> None:
        with self._lock, self._connection() as con:
            con.execute("UPDATE files SET sha256=?,last_error=NULL,updated_at=CURRENT_TIMESTAMP WHERE path=?", (sha256, path))

    def media_needs_refresh(self, path: str, expected_kind: str) -> bool:
        with self._connection() as con:
            row = con.execute("SELECT media_kind,metadata_json,media_error FROM files WHERE path=?", (path,)).fetchone()
            return row is None or row["media_kind"] != expected_kind or row["metadata_json"] is None or bool(row["media_error"])

    def set_media_metadata(self, path: str, metadata: MediaMetadata) -> None:
        values = asdict(metadata)
        with self._lock, self._connection() as con:
            con.execute(
                """UPDATE files SET media_kind=:media_kind,mime_type=COALESCE(:mime_type,mime_type),width=:width,height=:height,
                duration_seconds=:duration_seconds,capture_time=:capture_time,camera_make=:camera_make,camera_model=:camera_model,
                metadata_json=:metadata_json,media_error=:media_error,updated_at=CURRENT_TIMESTAMP WHERE path=:path""",
                {**values, "path": path},
            )

    def prune_source(self, source_id: str, scan_token: str) -> int:
        with self._lock, self._connection() as con:
            cur = con.execute("DELETE FROM files WHERE source_id=? AND scan_token<>?", (source_id, scan_token))
            return cur.rowcount

    # ---------- chunk 3 metadata ----------
    def set_annotations(
        self, path: str, *, rating: int | None = None, favorite: bool | int | None = None,
        caption: str | None = None, tags: Iterable[str] | None = None,
    ) -> None:
        with self._lock, self._connection() as con:
            if rating is not None:
                rating = max(0, min(5, int(rating)))
                con.execute("UPDATE files SET rating=?,updated_at=CURRENT_TIMESTAMP WHERE path=?", (rating, path))
            if favorite is not None:
                con.execute("UPDATE files SET favorite=?,updated_at=CURRENT_TIMESTAMP WHERE path=?", (1 if favorite else 0, path))
            if caption is not None:
                con.execute("UPDATE files SET caption=?,updated_at=CURRENT_TIMESTAMP WHERE path=?", (caption.strip(), path))
            if tags is not None:
                file_row = con.execute("SELECT id FROM files WHERE path=?", (path,)).fetchone()
                if not file_row:
                    return
                file_id = int(file_row["id"])
                con.execute("DELETE FROM file_tags WHERE file_id=?", (file_id,))
                clean: list[str] = []
                seen_tags: set[str] = set()
                for raw_tag in tags:
                    tag = raw_tag.strip() if raw_tag else ""
                    key = tag.casefold()
                    if tag and key not in seen_tags:
                        seen_tags.add(key)
                        clean.append(tag)
                clean.sort(key=str.casefold)
                for tag in clean:
                    con.execute("INSERT INTO tags(name) VALUES(?) ON CONFLICT(name) DO NOTHING", (tag,))
                    tag_id = con.execute("SELECT id FROM tags WHERE name=? COLLATE NOCASE", (tag,)).fetchone()[0]
                    con.execute("INSERT OR IGNORE INTO file_tags(file_id,tag_id) VALUES(?,?)", (file_id, tag_id))
                con.execute("DELETE FROM tags WHERE id NOT IN (SELECT DISTINCT tag_id FROM file_tags)")

    def tags_for_file(self, path: str) -> list[str]:
        sql = """SELECT t.name FROM tags t JOIN file_tags ft ON ft.tag_id=t.id JOIN files f ON f.id=ft.file_id
                 WHERE f.path=? ORDER BY t.name COLLATE NOCASE"""
        with self._connection() as con:
            return [row["name"] for row in con.execute(sql, (path,))]

    def tag_counts(self) -> dict[str, int]:
        sql = """SELECT t.name,COUNT(*) AS n FROM tags t JOIN file_tags ft ON ft.tag_id=t.id
                 JOIN files f ON f.id=ft.file_id WHERE f.media_kind IN ('image','video') GROUP BY t.id ORDER BY t.name COLLATE NOCASE"""
        with self._connection() as con:
            return {row["name"]: int(row["n"]) for row in con.execute(sql)}

    def create_album(self, name: str) -> int:
        clean = name.strip()
        if not clean:
            raise ValueError("Album name cannot be empty")
        with self._lock, self._connection() as con:
            con.execute("INSERT INTO albums(name) VALUES(?) ON CONFLICT(name) DO NOTHING", (clean,))
            row = con.execute("SELECT id FROM albums WHERE name=? COLLATE NOCASE", (clean,)).fetchone()
            return int(row["id"])

    def albums_with_counts(self) -> list[tuple[int, str, int]]:
        sql = """SELECT a.id,a.name,COUNT(af.file_id) AS n FROM albums a LEFT JOIN album_files af ON af.album_id=a.id
                 GROUP BY a.id ORDER BY a.name COLLATE NOCASE"""
        with self._connection() as con:
            return [(int(row["id"]), row["name"], int(row["n"])) for row in con.execute(sql)]

    def add_file_to_album(self, path: str, album_id: int) -> bool:
        with self._lock, self._connection() as con:
            row = con.execute("SELECT id FROM files WHERE path=?", (path,)).fetchone()
            if not row:
                return False
            con.execute("INSERT OR IGNORE INTO album_files(album_id,file_id) VALUES(?,?)", (album_id, int(row["id"])))
            return True

    def remove_file_from_album(self, path: str, album_id: int) -> None:
        with self._lock, self._connection() as con:
            con.execute(
                "DELETE FROM album_files WHERE album_id=? AND file_id=(SELECT id FROM files WHERE path=?)",
                (album_id, path),
            )

    def albums_for_file(self, path: str) -> list[tuple[int, str]]:
        sql = """SELECT a.id,a.name FROM albums a JOIN album_files af ON af.album_id=a.id
                 JOIN files f ON f.id=af.file_id WHERE f.path=? ORDER BY a.name COLLATE NOCASE"""
        with self._connection() as con:
            return [(int(row["id"]), row["name"]) for row in con.execute(sql, (path,))]

    # ---------- queries ----------
    def duplicate_size_candidates(self) -> list[FileRow]:
        sql = f"SELECT {_SELECT} FROM files WHERE size>0 AND size IN (SELECT size FROM files WHERE size>0 GROUP BY size HAVING COUNT(*)>1) ORDER BY size,path"
        with self._connection() as con:
            return [FileRow(**dict(row)) for row in con.execute(sql)]

    def duplicate_groups(self) -> list[tuple[str, int, list[str]]]:
        sql = """SELECT sha256,size,GROUP_CONCAT(path,char(31)) AS paths,COUNT(*) AS copies FROM files
                 WHERE sha256 IS NOT NULL AND sha256<>'' GROUP BY sha256,size HAVING COUNT(*)>1
                 ORDER BY (size*COUNT(*)) DESC,size DESC"""
        groups = []
        with self._connection() as con:
            for row in con.execute(sql):
                groups.append((row["sha256"], row["size"], row["paths"].split(chr(31))))
        return groups

    @staticmethod
    def _search_clause(query: str) -> tuple[str, list[str]]:
        q = f"%{query.strip().lower()}%"
        clause = """(
            lower(f.path) LIKE ? OR lower(COALESCE(f.file_type,'')) LIKE ? OR lower(COALESCE(f.file_category,'')) LIKE ?
            OR lower(COALESCE(f.caption,'')) LIKE ? OR EXISTS (
                SELECT 1 FROM file_tags ft JOIN tags t ON t.id=ft.tag_id WHERE ft.file_id=f.id AND lower(t.name) LIKE ?
            )
        )"""
        return clause, [q, q, q, q, q]

    def file_by_path(self, path: str) -> FileRow | None:
        with self._connection() as con:
            row = con.execute(f"SELECT {_SELECT} FROM files WHERE path=?", (path,)).fetchone()
            return FileRow(**dict(row)) if row else None

    def all_files(
        self, limit: int = 5000, *, sort_by: str = "path", descending: bool = False, query: str = "",
    ) -> list[FileRow]:
        expression = _SORT_EXPRESSIONS.get(sort_by, _SORT_EXPRESSIONS["path"])
        direction = "DESC" if descending else "ASC"
        where = ""
        params: list[object] = []
        if query.strip():
            clause, p = self._search_clause(query)
            where = "WHERE " + clause
            params.extend(p)
        params.append(limit)
        sql = f"SELECT {_SELECT} FROM files f {where} ORDER BY {expression} {direction}, path COLLATE NOCASE ASC LIMIT ?"
        with self._connection() as con:
            return [FileRow(**dict(row)) for row in con.execute(sql, params)]

    def media_files(
        self, *, limit: int = 240, folder_prefix: str | None = None, date_prefix: str | None = None,
        media_kind: str | None = None, favorite: bool = False, tag: str | None = None,
        album_id: int | None = None, query: str = "",
    ) -> list[FileRow]:
        clauses = ["f.media_kind IN ('image','video')"]
        params: list[object] = []
        if folder_prefix:
            prefix = folder_prefix.rstrip("/") + "/%"
            clauses.append("(f.parent_path=? OR f.path LIKE ?)")
            params.extend([folder_prefix, prefix])
        if date_prefix:
            clauses.append("f.capture_time LIKE ?")
            params.append(date_prefix + "%")
        if media_kind in {"image", "video"}:
            clauses.append("f.media_kind=?")
            params.append(media_kind)
        if favorite:
            clauses.append("f.favorite=1")
        if tag:
            clauses.append("EXISTS (SELECT 1 FROM file_tags ft JOIN tags t ON t.id=ft.tag_id WHERE ft.file_id=f.id AND t.name=? COLLATE NOCASE)")
            params.append(tag)
        if album_id is not None:
            clauses.append("EXISTS (SELECT 1 FROM album_files af WHERE af.file_id=f.id AND af.album_id=?)")
            params.append(album_id)
        if query.strip():
            clause, p = self._search_clause(query)
            clauses.append(clause)
            params.extend(p)
        params.append(limit)
        sql = f"SELECT {_SELECT} FROM files f WHERE {' AND '.join(clauses)} ORDER BY COALESCE(f.capture_time,'') DESC,f.path COLLATE NOCASE LIMIT ?"
        with self._connection() as con:
            return [FileRow(**dict(row)) for row in con.execute(sql, params)]

    def media_counts(self) -> dict[str, int]:
        with self._connection() as con:
            rows = con.execute("SELECT media_kind,COUNT(*) AS n FROM files GROUP BY media_kind").fetchall()
        counts = {"image": 0, "video": 0, "other": 0}
        for row in rows:
            counts[row["media_kind"]] = int(row["n"])
        return counts

    def category_counts(self) -> dict[str, int]:
        with self._connection() as con:
            return {row["file_category"]: int(row["n"]) for row in con.execute(
                "SELECT file_category,COUNT(*) AS n FROM files GROUP BY file_category ORDER BY n DESC"
            )}

    def folder_counts(self) -> dict[str, int]:
        # SQL grouping avoids constructing every FileRow just to build the navigation tree.
        sql = """SELECT COALESCE(parent_path,source_root) AS folder,COUNT(*) AS n FROM files
                 WHERE media_kind IN ('image','video') GROUP BY folder ORDER BY folder COLLATE NOCASE"""
        with self._connection() as con:
            return {row["folder"]: int(row["n"]) for row in con.execute(sql) if row["folder"]}

    def date_counts(self) -> dict[str, int]:
        sql = "SELECT substr(capture_time,1,7) AS ym,COUNT(*) AS n FROM files WHERE media_kind IN ('image','video') AND capture_time IS NOT NULL GROUP BY ym ORDER BY ym DESC"
        with self._connection() as con:
            return {row["ym"]: int(row["n"]) for row in con.execute(sql) if row["ym"]}

    def source_media_counts(self) -> dict[str, int]:
        sql = "SELECT source_root,COUNT(*) AS n FROM files WHERE media_kind IN ('image','video') GROUP BY source_root ORDER BY source_root"
        with self._connection() as con:
            return {row["source_root"]: int(row["n"]) for row in con.execute(sql)}

    def favorite_count(self) -> int:
        with self._connection() as con:
            return int(con.execute("SELECT COUNT(*) FROM files WHERE media_kind IN ('image','video') AND favorite=1").fetchone()[0])

    def count_files(self) -> int:
        with self._connection() as con:
            return int(con.execute("SELECT COUNT(*) FROM files").fetchone()[0])
