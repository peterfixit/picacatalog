from __future__ import annotations

import json
import mimetypes
import shutil
import subprocess
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import ExifTags, Image

IMAGE_EXTENSIONS = {
    ".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp",
    ".tif", ".tiff", ".avif", ".heic", ".heif", ".dng", ".raw",
    ".cr2", ".cr3", ".nef", ".arw", ".orf", ".rw2",
}
VIDEO_EXTENSIONS = {
    ".mp4", ".m4v", ".mov", ".avi", ".mkv", ".webm", ".wmv",
    ".flv", ".mpeg", ".mpg", ".mts", ".m2ts", ".3gp", ".ogv", ".ts",
}
AUDIO_EXTENSIONS = {
    ".mp3", ".flac", ".wav", ".m4a", ".aac", ".ogg", ".opus", ".wma",
    ".aiff", ".aif", ".ape", ".alac", ".mid", ".midi",
}
DOCUMENT_EXTENSIONS = {
    ".pdf", ".txt", ".rtf", ".md", ".doc", ".docx", ".odt", ".pages",
    ".xls", ".xlsx", ".ods", ".csv", ".ppt", ".pptx", ".odp", ".epub",
    ".mobi", ".azw", ".azw3",
}
ARCHIVE_EXTENSIONS = {
    ".zip", ".rar", ".7z", ".tar", ".gz", ".tgz", ".bz2", ".tbz2",
    ".xz", ".txz", ".zst", ".lz", ".lz4", ".cab",
}
PACKAGE_EXTENSIONS = {
    ".appimage", ".flatpak", ".flatpakref", ".deb", ".rpm", ".msi", ".exe",
    ".apk", ".xapk", ".ipa", ".pkg", ".dmg", ".snap",
}
DISK_IMAGE_EXTENSIONS = {".iso", ".img", ".vhd", ".vhdx", ".vmdk", ".qcow", ".qcow2", ".ova", ".ovf"}
CODE_EXTENSIONS = {
    ".py", ".pyw", ".js", ".ts", ".jsx", ".tsx", ".html", ".htm", ".css",
    ".scss", ".c", ".h", ".cc", ".cpp", ".hpp", ".rs", ".go", ".java",
    ".kt", ".kts", ".swift", ".php", ".rb", ".pl", ".lua", ".cs", ".vb",
    ".sh", ".bash", ".zsh", ".fish", ".ps1", ".bat", ".cmd",
}
DATA_EXTENSIONS = {".json", ".xml", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".log"}
DATABASE_EXTENSIONS = {".db", ".sqlite", ".sqlite3", ".mdb", ".accdb", ".sql"}
FONT_EXTENSIONS = {".ttf", ".otf", ".woff", ".woff2", ".eot"}

TYPE_LABELS = {
    ".jpg": "JPEG image", ".jpeg": "JPEG image", ".jpe": "JPEG image",
    ".png": "PNG image", ".webp": "WebP image", ".gif": "GIF image",
    ".bmp": "Bitmap image", ".tif": "TIFF image", ".tiff": "TIFF image",
    ".heic": "HEIC image", ".heif": "HEIF image", ".avif": "AVIF image",
    ".dng": "Digital Negative (DNG)", ".cr2": "Canon RAW image", ".cr3": "Canon RAW image",
    ".nef": "Nikon RAW image", ".arw": "Sony RAW image", ".orf": "Olympus RAW image",
    ".rw2": "Panasonic RAW image",
    ".mp4": "MPEG-4 video", ".m4v": "M4V video", ".mov": "QuickTime video",
    ".avi": "AVI video", ".mkv": "Matroska video", ".webm": "WebM video",
    ".wmv": "Windows Media video", ".mpeg": "MPEG video", ".mpg": "MPEG video",
    ".mts": "AVCHD video", ".m2ts": "MPEG-2 transport stream", ".ts": "MPEG transport stream",
    ".mp3": "MP3 audio", ".flac": "FLAC audio", ".wav": "WAV audio", ".m4a": "M4A audio",
    ".aac": "AAC audio", ".ogg": "Ogg audio", ".opus": "Opus audio", ".wma": "Windows Media audio",
    ".pdf": "PDF document", ".txt": "Text document", ".rtf": "Rich Text document", ".md": "Markdown document",
    ".doc": "Microsoft Word document", ".docx": "Microsoft Word document", ".odt": "OpenDocument text",
    ".xls": "Microsoft Excel workbook", ".xlsx": "Microsoft Excel workbook", ".ods": "OpenDocument spreadsheet",
    ".csv": "CSV data", ".ppt": "Microsoft PowerPoint presentation", ".pptx": "Microsoft PowerPoint presentation",
    ".odp": "OpenDocument presentation", ".epub": "EPUB ebook", ".mobi": "Mobipocket ebook",
    ".zip": "ZIP archive", ".rar": "RAR archive", ".7z": "7-Zip archive", ".tar": "TAR archive",
    ".gz": "Gzip archive", ".tgz": "Gzip TAR archive", ".bz2": "Bzip2 archive", ".xz": "XZ archive",
    ".zst": "Zstandard archive", ".appimage": "Linux AppImage", ".flatpak": "Flatpak bundle",
    ".flatpakref": "Flatpak reference", ".deb": "Debian package", ".rpm": "RPM package",
    ".msi": "Windows Installer package", ".exe": "Windows executable / installer", ".apk": "Android package",
    ".pkg": "Software package", ".dmg": "Apple disk image", ".iso": "ISO disk image", ".img": "Disk image",
    ".vhd": "Virtual hard disk", ".vhdx": "Virtual hard disk", ".vmdk": "VMware virtual disk",
    ".qcow": "QEMU disk image", ".qcow2": "QEMU disk image", ".ova": "Virtual appliance",
    ".db": "Database file", ".sqlite": "SQLite database", ".sqlite3": "SQLite database", ".sql": "SQL script",
    ".ttf": "TrueType font", ".otf": "OpenType font", ".woff": "Web font", ".woff2": "Web font",
}


@dataclass
class MediaMetadata:
    media_kind: str
    mime_type: str | None = None
    width: int | None = None
    height: int | None = None
    duration_seconds: float | None = None
    capture_time: str | None = None
    camera_make: str | None = None
    camera_model: str | None = None
    metadata_json: str = "{}"
    media_error: str | None = None


@dataclass(frozen=True)
class ResolvedFileType:
    category: str
    label: str
    mime_type: str | None


def _sniff_image_signature(path: Path) -> tuple[str, str] | None:
    """Recognize common image formats by file signature, independent of filename."""
    try:
        with path.open("rb") as handle:
            head = handle.read(16)
    except (OSError, PermissionError, IsADirectoryError):
        return None
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "PNG image", "image/png"
    if head.startswith(b"\xff\xd8\xff"):
        return "JPEG image", "image/jpeg"
    if head.startswith((b"GIF87a", b"GIF89a")):
        return "GIF image", "image/gif"
    if len(head) >= 12 and head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "WebP image", "image/webp"
    return None


def detect_media_kind(path: Path) -> tuple[str, str | None]:
    suffix = path.suffix.lower()
    mime, _encoding = mimetypes.guess_type(str(path))
    if suffix in IMAGE_EXTENSIONS or (mime and mime.startswith("image/")):
        return "image", mime or f"image/{suffix.lstrip('.')}"
    if suffix in VIDEO_EXTENSIONS or (mime and mime.startswith("video/")):
        return "video", mime or f"video/{suffix.lstrip('.')}"
    sniffed = _sniff_image_signature(path)
    if sniffed:
        return "image", sniffed[1]
    return "other", mime


def _category_from_mime(mime: str | None) -> str | None:
    if not mime:
        return None
    major = mime.split("/", 1)[0]
    if major == "image": return "image"
    if major == "video": return "video"
    if major == "audio": return "audio"
    if major == "text": return "document"
    if mime in {"application/pdf", "application/rtf"}: return "document"
    if "zip" in mime or "compressed" in mime or "archive" in mime: return "archive"
    return None


def resolve_file_type(path: Path, *, use_file_command: bool = True) -> ResolvedFileType:
    """Resolve a practical user-facing type without requiring a server or Python magic bindings.

    Known extensions are categorized immediately. For unknown extensions we optionally ask the local
    `file` utility for MIME + description. This keeps common scans fast while still resolving arbitrary
    installers/binaries/data files much better than a generic 'other'.
    """
    suffix = path.suffix.lower()
    lower_name = path.name.lower()
    mime, _encoding = mimetypes.guess_type(str(path))
    sniffed_image = _sniff_image_signature(path) if path.exists() and path.is_file() else None
    if sniffed_image:
        return ResolvedFileType("image", sniffed_image[0], sniffed_image[1])

    # compound Linux package/archive suffixes first
    if lower_name.endswith(".pkg.tar.zst") or lower_name.endswith(".pkg.tar.xz"):
        return ResolvedFileType("package", "Arch Linux package", mime or "application/zstd")
    if lower_name.endswith(".tar.gz") or lower_name.endswith(".tar.xz") or lower_name.endswith(".tar.bz2"):
        return ResolvedFileType("archive", "Compressed TAR archive", mime)

    if suffix in IMAGE_EXTENSIONS: category = "image"
    elif suffix in VIDEO_EXTENSIONS: category = "video"
    elif suffix in AUDIO_EXTENSIONS: category = "audio"
    elif suffix in DOCUMENT_EXTENSIONS: category = "document"
    elif suffix in ARCHIVE_EXTENSIONS: category = "archive"
    elif suffix in PACKAGE_EXTENSIONS: category = "package"
    elif suffix in DISK_IMAGE_EXTENSIONS: category = "disk-image"
    elif suffix in DATABASE_EXTENSIONS: category = "database"
    elif suffix in FONT_EXTENSIONS: category = "font"
    elif suffix in CODE_EXTENSIONS: category = "code"
    elif suffix in DATA_EXTENSIONS: category = "data"
    else: category = _category_from_mime(mime) or "other"

    if suffix in TYPE_LABELS:
        return ResolvedFileType(category, TYPE_LABELS[suffix], mime)

    if category != "other":
        ext = suffix.lstrip(".").upper()
        friendly_category = {
            "image": "image", "video": "video", "audio": "audio", "document": "document",
            "archive": "archive", "package": "package / installer", "disk-image": "disk image",
            "database": "database", "font": "font", "code": "source / script", "data": "data file",
        }.get(category, "file")
        label = f"{ext} {friendly_category}" if ext else friendly_category.title()
        return ResolvedFileType(category, label, mime)

    if use_file_command and shutil.which("file"):
        try:
            mime_proc = subprocess.run(
                ["file", "-b", "--mime-type", "--", str(path)],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=4, check=False,
            )
            desc_proc = subprocess.run(
                ["file", "-b", "--", str(path)],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=4, check=False,
            )
            resolved_mime = mime_proc.stdout.strip() if mime_proc.returncode == 0 else mime
            description = desc_proc.stdout.strip() if desc_proc.returncode == 0 else ""
            category = _category_from_mime(resolved_mime) or "other"
            if description:
                # file(1) descriptions can be huge; keep the useful leading part in the UI/database.
                description = description.split(", BuildID", 1)[0].strip()
                if len(description) > 180:
                    description = description[:177] + "…"
                return ResolvedFileType(category, description, resolved_mime or mime)
            mime = resolved_mime or mime
        except (OSError, subprocess.TimeoutExpired):
            pass

    if suffix:
        return ResolvedFileType("other", f"{suffix.lstrip('.').upper()} file", mime)
    return ResolvedFileType("other", "File", mime)


def _fallback_capture_time(path: Path) -> str | None:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat(timespec="seconds")
    except OSError:
        return None


def _parse_exif_datetime(value: Any) -> str | None:
    if not value:
        return None
    text = str(value).strip()
    for fmt in ("%Y:%m:%d %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text[:19], fmt).isoformat(timespec="seconds")
        except ValueError:
            pass
    return None


def _json_safe(value: Any) -> Any:
    if isinstance(value, bytes):
        return f"<{len(value)} bytes>"
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    return str(value)


def _extract_image(path: Path, mime: str | None) -> MediaMetadata:
    raw: dict[str, Any] = {}
    try:
        with Image.open(path) as image:
            width, height = image.size
            fmt = image.format
            if fmt:
                raw["format"] = fmt
            if image.mode:
                raw["mode"] = image.mode

            exif_named: dict[str, Any] = {}
            try:
                exif = image.getexif()
                for tag_id, value in exif.items():
                    name = ExifTags.TAGS.get(tag_id, str(tag_id))
                    exif_named[name] = _json_safe(value)
            except Exception as exc:
                raw["exif_error"] = str(exc)

            raw["exif"] = exif_named
            capture = (
                _parse_exif_datetime(exif_named.get("DateTimeOriginal"))
                or _parse_exif_datetime(exif_named.get("DateTimeDigitized"))
                or _parse_exif_datetime(exif_named.get("DateTime"))
                or _fallback_capture_time(path)
            )
            make = str(exif_named.get("Make", "")).strip() or None
            model = str(exif_named.get("Model", "")).strip() or None
            return MediaMetadata(
                media_kind="image",
                mime_type=Image.MIME.get(fmt, mime) if fmt else mime,
                width=width,
                height=height,
                capture_time=capture,
                camera_make=make,
                camera_model=model,
                metadata_json=json.dumps(raw, ensure_ascii=False, sort_keys=True),
            )
    except Exception as exc:
        return MediaMetadata(
            media_kind="image", mime_type=mime, capture_time=_fallback_capture_time(path),
            metadata_json="{}", media_error=str(exc),
        )


def _parse_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _extract_video(path: Path, mime: str | None) -> MediaMetadata:
    capture = _fallback_capture_time(path)
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return MediaMetadata(
            media_kind="video", mime_type=mime, capture_time=capture, metadata_json="{}",
            media_error="ffprobe is not installed; basic video catalogue entry only",
        )

    try:
        proc = subprocess.run(
            [ffprobe, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(path)],
            check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return MediaMetadata(media_kind="video", mime_type=mime, capture_time=capture, metadata_json="{}", media_error=str(exc))

    if proc.returncode != 0:
        err = proc.stderr.strip() or f"ffprobe exited with {proc.returncode}"
        return MediaMetadata(media_kind="video", mime_type=mime, capture_time=capture, metadata_json="{}", media_error=err)

    try:
        payload = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        payload = {}
        parse_error = str(exc)
    else:
        parse_error = None

    streams = payload.get("streams", []) if isinstance(payload, dict) else []
    video_stream = next((s for s in streams if s.get("codec_type") == "video"), {})
    fmt = payload.get("format", {}) if isinstance(payload, dict) else {}

    width = video_stream.get("width")
    height = video_stream.get("height")
    duration = _parse_float(video_stream.get("duration")) or _parse_float(fmt.get("duration"))
    tags = {}
    if isinstance(fmt, dict): tags.update(fmt.get("tags") or {})
    if isinstance(video_stream, dict): tags.update(video_stream.get("tags") or {})

    creation_time = tags.get("creation_time")
    if creation_time:
        try:
            capture = datetime.fromisoformat(str(creation_time).replace("Z", "+00:00")).isoformat(timespec="seconds")
        except ValueError:
            pass

    return MediaMetadata(
        media_kind="video", mime_type=mime,
        width=int(width) if width is not None else None,
        height=int(height) if height is not None else None,
        duration_seconds=duration, capture_time=capture,
        metadata_json=json.dumps(_json_safe(payload), ensure_ascii=False, sort_keys=True),
        media_error=parse_error,
    )


def extract_media_metadata(path: Path, kind: str | None = None, mime: str | None = None) -> MediaMetadata:
    detected_kind, detected_mime = detect_media_kind(path)
    kind = kind or detected_kind
    mime = mime or detected_mime
    if kind == "image": return _extract_image(path, mime)
    if kind == "video": return _extract_video(path, mime)
    return MediaMetadata(media_kind="other", mime_type=mime, capture_time=_fallback_capture_time(path), metadata_json="{}")
