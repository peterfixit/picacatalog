from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class SourceIdentity:
    source_id: str
    identity_key: str
    root: str
    label: str | None
    filesystem_uuid: str | None
    device_source: str | None
    mount_target: str | None


def _findmnt_value(root: Path, field: str) -> str | None:
    if not shutil.which("findmnt"):
        return None
    try:
        proc = subprocess.run(
            ["findmnt", "-T", str(root), "-n", "-o", field],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=3,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    value = proc.stdout.strip() if proc.returncode == 0 else ""
    return value or None


def identify_source(root: Path) -> SourceIdentity:
    """Create a stable-enough identity for a configured source folder.

    If findmnt is available, filesystem UUID + the folder's path relative to the mount
    is used. That lets a removable drive be recognized if its mount point changes.
    A st_dev-based fallback is used on systems without findmnt/UUID information.
    """
    root = root.expanduser().resolve()
    stat = root.stat()
    fs_uuid = _findmnt_value(root, "UUID")
    mount_target = _findmnt_value(root, "TARGET")
    label = _findmnt_value(root, "LABEL")
    device_source = _findmnt_value(root, "SOURCE")

    relative = "."
    if mount_target:
        try:
            relative = str(root.relative_to(Path(mount_target).resolve())) or "."
        except (ValueError, OSError):
            relative = str(root)

    if fs_uuid:
        identity_key = f"uuid:{fs_uuid}|rel:{relative}"
    else:
        # st_dev remains useful for a mounted source within one boot/session. Include the
        # relative/root path to avoid conflating two configured folders on the same volume.
        identity_key = f"dev:{stat.st_dev}|rel:{relative if mount_target else str(root)}"

    source_id = hashlib.sha256(identity_key.encode("utf-8", "surrogatepass")).hexdigest()[:24]
    return SourceIdentity(
        source_id=source_id,
        identity_key=identity_key,
        root=str(root),
        label=label or root.name or str(root),
        filesystem_uuid=fs_uuid,
        device_source=device_source,
        mount_target=mount_target,
    )
