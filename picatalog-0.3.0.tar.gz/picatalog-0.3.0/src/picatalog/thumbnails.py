from __future__ import annotations

import hashlib
import shutil
import subprocess
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

THUMB_SIZE = (220, 160)


def _cache_key(path: Path) -> str:
    try:
        stat = path.stat()
        material = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}".encode("utf-8", "surrogateescape")
    except OSError:
        material = str(path).encode("utf-8", "surrogateescape")
    return hashlib.sha256(material).hexdigest()


def thumbnail_path(cache_dir: Path, path: Path) -> Path:
    return cache_dir / _cache_key(path)[:2] / f"{_cache_key(path)}.jpg"


def _canvas() -> Image.Image:
    return Image.new("RGB", THUMB_SIZE, (42, 42, 42))


def _fit_image(image: Image.Image) -> Image.Image:
    image = ImageOps.exif_transpose(image).convert("RGB")
    image.thumbnail(THUMB_SIZE, Image.Resampling.LANCZOS)
    canvas = _canvas()
    x = (THUMB_SIZE[0] - image.width) // 2
    y = (THUMB_SIZE[1] - image.height) // 2
    canvas.paste(image, (x, y))
    return canvas


def _placeholder(label: str) -> Image.Image:
    image = _canvas()
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    text = label[:32]
    bbox = draw.textbbox((0, 0), text, font=font)
    x = max(8, (THUMB_SIZE[0] - (bbox[2] - bbox[0])) // 2)
    y = max(8, (THUMB_SIZE[1] - (bbox[3] - bbox[1])) // 2)
    draw.text((x, y), text, fill=(230, 230, 230), font=font)
    return image


def _video_frame(path: Path) -> Image.Image | None:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return None
    with tempfile.TemporaryDirectory(prefix="picatalog-thumb-") as td:
        frame = Path(td) / "frame.jpg"
        proc = subprocess.run(
            [
                ffmpeg,
                "-hide_banner", "-loglevel", "error",
                "-ss", "1",
                "-i", str(path),
                "-frames:v", "1",
                "-vf", "scale=440:-2:force_original_aspect_ratio=decrease",
                "-y", str(frame),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=30,
            check=False,
        )
        if proc.returncode != 0 or not frame.exists():
            return None
        try:
            with Image.open(frame) as image:
                return _fit_image(image)
        except Exception:
            return None


def ensure_thumbnail(path: Path, kind: str, cache_dir: Path) -> Path:
    dest = thumbnail_path(cache_dir, path)
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)

    image: Image.Image
    if kind == "image":
        try:
            with Image.open(path) as opened:
                image = _fit_image(opened)
        except Exception:
            image = _placeholder(path.suffix.upper().lstrip(".") or "IMAGE")
    elif kind == "video":
        image = _video_frame(path) or _placeholder("VIDEO")
    else:
        image = _placeholder(path.suffix.upper().lstrip(".") or "FILE")

    tmp = dest.with_suffix(".tmp.jpg")
    image.save(tmp, "JPEG", quality=86, optimize=True)
    tmp.replace(dest)
    return dest
