from __future__ import annotations

import hashlib
import logging
import os
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

from .catalog import Catalog
from .media import detect_media_kind, extract_media_metadata, resolve_file_type
from .paths import thumbnail_dir
from .source_identity import identify_source
from .thumbnails import ensure_thumbnail

ProgressCallback = Callable[[dict], None]
TYPE_RESOLVER_VERSION = "3"


@dataclass
class ScanSummary:
    sources: int = 0
    files_seen: int = 0
    indexed: int = 0
    types_resolved: int = 0
    media_indexed: int = 0
    thumbnails_generated: int = 0
    hashed: int = 0
    hidden_skipped: int = 0
    errors: int = 0
    pruned: int = 0
    sources_online: int = 0
    sources_offline: int = 0
    elapsed_seconds: float = 0.0


def _sha256_file(path: Path, block_size: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb", buffering=0) as handle:
        while chunk := handle.read(block_size):
            digest.update(chunk)
    return digest.hexdigest()


def _is_hidden_name(name: str) -> bool:
    return name.startswith(".") and name not in {".", ".."}


def scan_sources(
    catalog: Catalog,
    sources: Iterable[str],
    progress: ProgressCallback | None = None,
    logger: logging.Logger | None = None,
    build_thumbnails: bool = True,
    include_hidden: bool = False,
) -> ScanSummary:
    logger = logger or logging.getLogger("picatalog")
    progress = progress or (lambda event: None)
    started = time.monotonic()
    summary = ScanSummary()
    thumb_root = thumbnail_dir()
    force_type_refresh = catalog.get_setting("type_resolver_version", "") != TYPE_RESOLVER_VERSION

    normalized_sources: list[Path] = []
    seen_roots: set[str] = set()
    for raw in sources:
        root = Path(raw).expanduser().absolute()
        key = str(root)
        if key not in seen_roots:
            seen_roots.add(key)
            normalized_sources.append(root)
    summary.sources = len(normalized_sources)

    for configured_root in normalized_sources:
        if not configured_root.exists() or not configured_root.is_dir():
            summary.sources_offline += 1
            catalog.mark_source_offline_by_path(str(configured_root))
            msg = f"Source is offline or unavailable: {configured_root}"
            logger.warning(msg)
            progress({"phase": "source-offline", "source": str(configured_root), "message": msg})
            continue

        try:
            identity = identify_source(configured_root)
        except OSError as exc:
            summary.errors += 1
            msg = f"Cannot identify source {configured_root}: {exc}"
            logger.warning(msg)
            progress({"phase": "error", "source": str(configured_root), "message": msg})
            continue

        root = Path(identity.root)
        summary.sources_online += 1
        previous = catalog.register_source(
            source_id=identity.source_id,
            identity_key=identity.identity_key,
            configured_path=str(configured_root),
            current_path=str(root),
            label=identity.label,
            filesystem_uuid=identity.filesystem_uuid,
            device_source=identity.device_source,
        )
        if previous and previous != str(root):
            progress({
                "phase": "source",
                "source": str(root),
                "message": f"Recognized moved source: {previous} → {root}",
            })
            logger.info("Recognized moved source %s: %s -> %s", identity.source_id, previous, root)

        scan_token = str(uuid.uuid4())
        progress({"phase": "source", "source": str(root), "message": f"Scanning {root}"})
        logger.info("Scanning source: %s (%s)", root, identity.source_id)

        for current, dirs, files in os.walk(root, followlinks=False):
            kept_dirs = []
            for dirname in dirs:
                candidate = Path(current, dirname)
                if candidate.is_symlink():
                    continue
                if not include_hidden and _is_hidden_name(dirname):
                    summary.hidden_skipped += 1
                    continue
                kept_dirs.append(dirname)
            dirs[:] = kept_dirs

            for filename in files:
                if not include_hidden and _is_hidden_name(filename):
                    summary.hidden_skipped += 1
                    continue
                summary.files_seen += 1
                path = Path(current, filename)
                try:
                    if path.is_symlink():
                        continue
                    stat = path.stat()
                    catalog.upsert_file(
                        path=str(path), source_root=str(root), source_id=identity.source_id,
                        parent_path=str(path.parent), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                        scan_token=scan_token,
                    )
                    summary.indexed += 1

                    kind, mime = detect_media_kind(path)
                    if force_type_refresh or catalog.type_needs_refresh(str(path)):
                        resolved = resolve_file_type(path)
                        catalog.set_file_type(str(path), resolved.category, resolved.label, resolved.mime_type)
                        summary.types_resolved += 1
                        if not mime:
                            mime = resolved.mime_type

                    if kind in {"image", "video"} and catalog.media_needs_refresh(str(path), kind):
                        metadata = extract_media_metadata(path, kind, mime)
                        catalog.set_media_metadata(str(path), metadata)
                        summary.media_indexed += 1
                        if metadata.media_error:
                            logger.info("Media metadata warning for %s: %s", path, metadata.media_error)
                        if build_thumbnails:
                            try:
                                ensure_thumbnail(path, kind, thumb_root)
                                summary.thumbnails_generated += 1
                            except Exception as exc:
                                logger.warning("Cannot create thumbnail for %s: %s", path, exc)

                    if summary.indexed % 100 == 0:
                        progress({
                            "phase": "index", "source": str(root), "count": summary.indexed, "path": str(path),
                            "message": f"Indexed {summary.indexed:,} files · types {summary.types_resolved:,} · media {summary.media_indexed:,}",
                        })
                except (OSError, PermissionError) as exc:
                    summary.errors += 1
                    logger.warning("Cannot index %s: %s", path, exc)
                    progress({"phase": "error", "path": str(path), "message": str(exc)})

        removed = catalog.prune_source(identity.source_id, scan_token)
        summary.pruned += removed
        if removed:
            logger.info("Pruned %d stale/now-excluded entries for %s", removed, root)

    candidates = catalog.duplicate_size_candidates()
    total_candidates = len(candidates)
    progress({"phase": "hash-start", "count": total_candidates, "message": f"Hashing {total_candidates:,} duplicate-size candidates"})
    for idx, row in enumerate(candidates, start=1):
        if row.sha256:
            continue
        path = Path(row.path)
        try:
            catalog.set_hash(row.path, _sha256_file(path))
            summary.hashed += 1
        except (OSError, PermissionError) as exc:
            summary.errors += 1
            catalog.mark_error(row.path, str(exc))
            logger.warning("Cannot hash %s: %s", row.path, exc)
        if idx % 25 == 0 or idx == total_candidates:
            progress({
                "phase": "hash", "current": idx, "total": total_candidates, "path": row.path,
                "message": f"Hashing candidates {idx:,}/{total_candidates:,}",
            })

    catalog.set_setting("type_resolver_version", TYPE_RESOLVER_VERSION)
    summary.elapsed_seconds = time.monotonic() - started
    progress({"phase": "done", "summary": summary, "message": "Scan complete"})
    logger.info(
        "Scan complete: sources=%d online=%d offline=%d files=%d indexed=%d types=%d media=%d thumbs=%d hashed=%d hidden=%d errors=%d pruned=%d elapsed=%.2fs",
        summary.sources, summary.sources_online, summary.sources_offline, summary.files_seen, summary.indexed,
        summary.types_resolved, summary.media_indexed, summary.thumbnails_generated, summary.hashed,
        summary.hidden_skipped, summary.errors, summary.pruned, summary.elapsed_seconds,
    )
    return summary
