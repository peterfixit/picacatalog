#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if python3 -c 'import PIL' >/dev/null 2>&1; then
  TEST_PYTHON="$(command -v python3)"
else
  TEST_VENV="$ROOT/.venv-test"
  if [[ ! -x "$TEST_VENV/bin/python" ]]; then
    python3 -m venv "$TEST_VENV"
  fi
  if ! "$TEST_VENV/bin/python" -c 'import PIL' >/dev/null 2>&1; then
    "$TEST_VENV/bin/python" -m pip install -r "$ROOT/requirements-runtime.txt"
  fi
  TEST_PYTHON="$TEST_VENV/bin/python"
fi

export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
"$TEST_PYTHON" -m compileall -q "$ROOT/src"
"$TEST_PYTHON" -m unittest discover -s "$ROOT/tests" -p 'test_*.py' -v

if command -v xvfb-run >/dev/null 2>&1; then
  GUI_DATA="$(mktemp -d -t picatalog-gui-data.XXXXXX)"
  GUI_CACHE="$(mktemp -d -t picatalog-gui-cache.XXXXXX)"
  trap 'rm -rf "$GUI_DATA" "$GUI_CACHE"' EXIT
  XDG_DATA_HOME="$GUI_DATA" XDG_CACHE_HOME="$GUI_CACHE" xvfb-run -a "$TEST_PYTHON" "$ROOT/tests/gui_smoke.py"
  rm -rf "$GUI_DATA" "$GUI_CACHE"
  trap - EXIT
else
  echo "NOTE: xvfb-run unavailable; GUI smoke test skipped. Core tests still ran."
fi

bash -n "$ROOT/install-deps.sh"
bash -n "$ROOT/build.sh"
bash -n "$ROOT/build-appimage.sh"
bash -n "$ROOT/run-dev.sh"
PYTHONPATH="$ROOT/src" "$TEST_PYTHON" -c "import runpy; runpy.run_path('$ROOT/packaging/pyinstaller_entry.py', run_name='picatalog_build_entry_import_test')"
echo "All Chunk 3 self-tests passed."
