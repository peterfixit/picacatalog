# Changelog

## 0.3.0 — Chunk 3

### Reported fixes
- Added working sort commands to every useful **All Files** header with ascending/descending arrows.
- Moved All Files sorting into SQLite so Path/Type/Size/etc. sort raw catalogue values rather than display strings.
- Added dirty-page caching so switching sidebar tabs does not continually rebuild the media grid or thousands of file rows.
- Replaced Python-wide media folder counting with SQLite grouping.
- Limited one Library render to 240 media cards to keep Tk responsive on very large catalogues.
- Fixed Library scrolling for Linux/X11 `Button-4` / `Button-5` mouse-wheel events, while retaining normal MouseWheel support.

### Chunk 3
- Added favourites and 0–5 ratings.
- Added captions and tags.
- Added albums and Album navigation.
- Added Favourites and Tags navigation.
- Added local catalogue search across path/type/category/caption/tags.
- Added stable source identity records with filesystem UUID / relative-path detection through `findmnt` when available.
- Added source path rebasing for recognized removable storage mounted at a new path.
- Added offline-source preservation: a disconnected drive is marked offline and its catalogue entries are retained.
- Added source online/offline status to Storage.
- Added `--search` to the CLI.
- Added 17 core regression tests and a virtual-display GUI smoke test.

## 0.2.2 — Chunk 2.2
- Resizable Activity panel and persistent log.
- All Files double-click opening.
- Clickable Hidden Paths state.
- KDE native directory picker.
- Correct application icon/WM class.
- PNG signature detection.

## 0.2.1 — Chunk 2.1
- Uppy-style desktop shell.
- Clear Results / Start Over.
- Hidden path preference.
- Resolved general file types.

## 0.2.0 — Chunk 2
- Photo/video metadata, thumbnails, media grid, folder/date navigation and viewer.

## 0.1.1
- Fixed PyInstaller package entry point and added packaging smoke tests.
