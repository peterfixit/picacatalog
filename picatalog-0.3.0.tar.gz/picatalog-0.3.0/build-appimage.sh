#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION")"
./build.sh

APPDIR="$ROOT/build/AppDir"
TOOLS="$ROOT/.tools"
rm -rf "$APPDIR"
mkdir -p \
  "$APPDIR/usr/bin" \
  "$APPDIR/usr/share/applications" \
  "$APPDIR/usr/share/icons/hicolor/scalable/apps" \
  "$APPDIR/usr/share/icons/hicolor/256x256/apps" \
  "$APPDIR/usr/share/metainfo" \
  "$TOOLS"

cp -a "$ROOT/dist/picatalog/." "$APPDIR/usr/bin/picatalog-runtime/"
cat > "$APPDIR/usr/bin/picatalog" <<'WRAP'
#!/usr/bin/env bash
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
exec "$HERE/picatalog-runtime/picatalog" "$@"
WRAP
chmod +x "$APPDIR/usr/bin/picatalog"

cp "$ROOT/packaging/au.pmhs.picatalog.desktop" "$APPDIR/usr/share/applications/au.pmhs.picatalog.desktop"
cp "$ROOT/packaging/au.pmhs.picatalog.svg" "$APPDIR/usr/share/icons/hicolor/scalable/apps/au.pmhs.picatalog.svg"
cp "$ROOT/src/picatalog/assets/picatalog.png" "$APPDIR/usr/share/icons/hicolor/256x256/apps/au.pmhs.picatalog.png"
cp "$ROOT/packaging/au.pmhs.picatalog.desktop" "$APPDIR/au.pmhs.picatalog.desktop"
cp "$ROOT/packaging/au.pmhs.picatalog.svg" "$APPDIR/au.pmhs.picatalog.svg"
if [[ -f "$ROOT/packaging/au.pmhs.picatalog.metainfo.xml" ]]; then
  cp "$ROOT/packaging/au.pmhs.picatalog.metainfo.xml" "$APPDIR/usr/share/metainfo/au.pmhs.picatalog.metainfo.xml"
fi
ln -sfn au.pmhs.picatalog.svg "$APPDIR/.DirIcon"

cat > "$APPDIR/AppRun" <<'APP_RUN'
#!/usr/bin/env bash
set -e
HERE="$(dirname "$(readlink -f "$0")")"
exec "$HERE/usr/bin/picatalog" "$@"
APP_RUN
chmod +x "$APPDIR/AppRun"

ARCH="$(uname -m)"
case "$ARCH" in
  x86_64) TOOL_ARCH="x86_64" ;;
  aarch64|arm64) TOOL_ARCH="aarch64" ;;
  *) echo "Unsupported AppImage build architecture: $ARCH" >&2; exit 2 ;;
esac

APPIMAGETOOL="$TOOLS/appimagetool-$TOOL_ARCH.AppImage"
if [[ ! -x "$APPIMAGETOOL" ]]; then
  echo "Downloading appimagetool for build use only…"
  URL="https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-$TOOL_ARCH.AppImage"
  if command -v curl >/dev/null 2>&1; then
    curl -fL "$URL" -o "$APPIMAGETOOL"
  else
    wget -O "$APPIMAGETOOL" "$URL"
  fi
  chmod +x "$APPIMAGETOOL"
fi

mkdir -p "$ROOT/release"
OUT="$ROOT/release/PicaCatalog-${VERSION}-${TOOL_ARCH}.AppImage"
rm -f "$OUT"
ARCH="$TOOL_ARCH" "$APPIMAGETOOL" "$APPDIR" "$OUT" || \
ARCH="$TOOL_ARCH" "$APPIMAGETOOL" --appimage-extract-and-run "$APPDIR" "$OUT"
chmod +x "$OUT"

echo
echo "Running AppImage smoke test…"
if "$OUT" --appimage-extract-and-run --help >/dev/null 2>&1; then
  echo "AppImage launch smoke test passed (extract-and-run)."
elif "$OUT" --help >/dev/null 2>&1; then
  echo "AppImage launch smoke test passed."
else
  echo "ERROR: AppImage was created but failed its launch smoke test." >&2
  echo "Try manually: $OUT --appimage-extract-and-run --help" >&2
  exit 5
fi

echo
printf 'AppImage created: %s\n' "$OUT"
printf 'Run: %s\n' "$OUT"
printf 'If FUSE is unavailable: %s --appimage-extract-and-run\n' "$OUT"
