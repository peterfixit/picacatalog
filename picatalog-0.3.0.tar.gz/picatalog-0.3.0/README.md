# PicaCatalog 0.3.0 — Chunk 3

PicaCatalog is an offline-first Linux desktop catalogue inspired by classic local photo managers. It catalogues files where they already live and does not require a server, web service, NAS or cloud account.

## 0.3.0 fixes from 0.2.2

- **Sortable All Files headers**: click Path, Category, Resolved type, Size, Dimensions, Date, Rating, Favourite, SHA-256 or Error. Click the same header again to reverse the direction.
- **Much faster main-tab switching**: pages are cached and marked dirty only when a scan, search or metadata edit changes their data. Returning to Library no longer destroys/recreates the thumbnail grid every time.
- **Faster Library navigation rebuilds**: folder counts are grouped directly in SQLite instead of constructing every media row in Python.
- **Library mouse wheel fixed on Linux/X11**: both normal `<MouseWheel>` and X11 `<Button-4>/<Button-5>` events are supported. The wheel is only captured while the pointer is over the media canvas.
- Library display is capped at 240 media cards per filter to keep Tk responsive; the catalogue itself is not limited to 240 files.

## Chunk 3 features

- ★ Favourites.
- 0–5 ratings.
- Captions.
- Comma-separated tags.
- Albums.
- Local search across path, resolved type/category, caption and tags.
- Favourites, Albums and Tags appear in Library navigation.
- All metadata is kept in the local SQLite catalogue; original files are not modified.
- Persistent removable/offline source identities.
  - When `findmnt` can see a filesystem UUID, PicaCatalog records `filesystem UUID + folder-relative path`.
  - If the same removable source is later mounted at another path and added/scanned there, existing catalogue paths can be rebased while preserving ratings/tags/albums.
  - A disconnected configured source is marked **offline** and its catalogue entries are retained rather than pruned.
- Storage shows known source identities and online/offline state.

## Safety boundary

0.3.0 still contains **no automatic source-file move, rename, overwrite or delete engine**. Source media are read-only to PicaCatalog in this chunk. It writes only its catalogue, thumbnail cache and logs.

Runtime data:

```text
~/.local/share/picatalog/
├── catalog.db
└── logs/picatalog.log

~/.cache/picatalog/
└── thumbnails/
```

## Install dependencies

```bash
chmod +x install-deps.sh
./install-deps.sh
```

Supported families:

- Debian / Ubuntu / Mint / Pop!_OS
- Fedora / RHEL / Rocky / AlmaLinux
- Arch / CachyOS / Manjaro / EndeavourOS
- openSUSE / SLES

Local helpers:

- `file` improves unknown file-type descriptions.
- `ffmpeg` / `ffprobe` provide video metadata and thumbnails.
- `findmnt` from `util-linux` provides removable-source filesystem identity when available.
- KDE/Plasma uses `kdialog --getexistingdirectory` for the native KFileWidget-style folder picker.

## Upgrade from 0.1/0.2

Keep your existing catalogue:

```text
~/.local/share/picatalog/catalog.db
```

0.3.0 migrates the database in place. Run a normal scan once after upgrading so existing file rows receive source identity / parent-folder fields.

## Test

```bash
./selftest.sh
```

The test suite checks the core catalogue plus a GUI smoke test when `xvfb-run` is available. The GUI test covers sortable All Files headers, cached tab switching and Linux mouse-wheel scrolling.

## Run from source

```bash
./run-dev.sh
```

Add storage sources under **Storage**, for example:

```text
/home/you/Pictures
/mnt/photos
/media/you/USB-Backup
```

Hidden paths remain excluded by default.

## Headless examples

```bash
./run-dev.sh --scan /path/to/storage --media-summary --type-summary --duplicates
./run-dev.sh --search holiday
./run-dev.sh --scan /path/to/storage --include-hidden --type-summary
./run-dev.sh --clear-results
./run-dev.sh --start-over
```

## Build standalone

```bash
./build.sh
```

Output:

```text
dist/picatalog/picatalog
```

## Build AppImage

```bash
./build-appimage.sh
```

Output on x86-64:

```text
release/PicaCatalog-0.3.0-x86_64.AppImage
```

Run:

```bash
./release/PicaCatalog-0.3.0-x86_64.AppImage
```

If FUSE is unavailable:

```bash
./release/PicaCatalog-0.3.0-x86_64.AppImage --appimage-extract-and-run
```
