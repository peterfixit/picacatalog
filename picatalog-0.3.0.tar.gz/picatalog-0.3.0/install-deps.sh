#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -eq 0 ]]; then SUDO=""; else SUDO="sudo"; fi

DETECTED=""
if [[ -r /etc/os-release ]]; then
  # shellcheck disable=SC1091
  source /etc/os-release
  case "${ID:-}" in
    ubuntu|debian|linuxmint|pop) DETECTED="debian" ;;
    fedora|rhel|centos|rocky|almalinux) DETECTED="fedora" ;;
    arch|cachyos|manjaro|endeavouros) DETECTED="arch" ;;
    opensuse*|sles) DETECTED="suse" ;;
  esac
  if [[ -z "$DETECTED" ]]; then
    case "${ID_LIKE:-}" in
      *debian*) DETECTED="debian" ;;
      *fedora*|*rhel*) DETECTED="fedora" ;;
      *arch*) DETECTED="arch" ;;
      *suse*) DETECTED="suse" ;;
    esac
  fi
fi

printf '\nPicaCatalog dependency installer\n'
printf 'Detected family: %s\n\n' "${DETECTED:-unknown}"
printf '  1) Debian / Ubuntu / Mint / Pop!_OS\n'
printf '  2) Fedora / RHEL / Rocky / AlmaLinux\n'
printf '  3) Arch / CachyOS / Manjaro / EndeavourOS\n'
printf '  4) openSUSE / SLES\n'
printf '  5) Exit\n\n'

DEFAULT_CHOICE=""
case "$DETECTED" in
  debian) DEFAULT_CHOICE=1 ;;
  fedora) DEFAULT_CHOICE=2 ;;
  arch) DEFAULT_CHOICE=3 ;;
  suse) DEFAULT_CHOICE=4 ;;
esac

if [[ -n "$DEFAULT_CHOICE" ]]; then
  read -r -p "Select distro family [${DEFAULT_CHOICE}]: " choice
  choice="${choice:-$DEFAULT_CHOICE}"
else
  read -r -p "Select distro family: " choice
fi

case "$choice" in
  1)
    $SUDO apt-get update
    $SUDO apt-get install -y python3 python3-venv python3-pip python3-tk build-essential patchelf desktop-file-utils file wget curl xdg-utils ffmpeg util-linux
    $SUDO apt-get install -y kdialog 2>/dev/null || true
    $SUDO apt-get install -y libfuse2 2>/dev/null || $SUDO apt-get install -y libfuse2t64 2>/dev/null || true
    ;;
  2)
    $SUDO dnf install -y python3 python3-pip python3-tkinter gcc gcc-c++ make patchelf desktop-file-utils file wget curl xdg-utils fuse fuse-libs util-linux
    $SUDO dnf install -y kdialog 2>/dev/null || true
    $SUDO dnf install -y ffmpeg-free 2>/dev/null || $SUDO dnf install -y ffmpeg 2>/dev/null || \
      echo "NOTE: ffmpeg/ffprobe was not available in enabled Fedora/RHEL repositories. Photo support still works; install ffmpeg later for video metadata/thumbnails."
    ;;
  3)
    $SUDO pacman -Syu --needed --noconfirm python python-pip tk base-devel patchelf desktop-file-utils file wget curl xdg-utils fuse2 ffmpeg kdialog util-linux
    ;;
  4)
    $SUDO zypper --non-interactive install python3 python3-pip python3-tk gcc gcc-c++ make patchelf desktop-file-utils file wget curl xdg-utils fuse libfuse2 util-linux
    $SUDO zypper --non-interactive install kdialog 2>/dev/null || true
    $SUDO zypper --non-interactive install ffmpeg 2>/dev/null || \
      echo "NOTE: ffmpeg was not available in enabled openSUSE repositories. Photo support still works; install ffmpeg later for video metadata/thumbnails."
    ;;
  5) exit 0 ;;
  *) echo "Unknown selection: $choice" >&2; exit 2 ;;
esac

cat <<'MSG'

System dependencies installed.

Development run (creates an isolated .venv-dev for Pillow):
  ./run-dev.sh

Standalone build:
  ./build.sh

AppImage:
  ./build-appimage.sh

PicaCatalog itself remains offline at runtime. ffmpeg/ffprobe are used locally for video metadata and thumbnails. findmnt (util-linux) is used when available to persist removable-drive identities. On KDE/Plasma, kdialog provides the native KDE/KFileWidget-style directory picker.
MSG
