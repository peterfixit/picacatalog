#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if python3 -c 'import PIL' >/dev/null 2>&1; then
  PYTHON_BIN="$(command -v python3)"
else
  if [[ ! -x .venv-dev/bin/python ]]; then
    python3 -m venv .venv-dev
  fi
  if ! .venv-dev/bin/python -c 'import PIL' >/dev/null 2>&1; then
    .venv-dev/bin/python -m pip install -r requirements-runtime.txt
  fi
  PYTHON_BIN="$ROOT/.venv-dev/bin/python"
fi

export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
exec "$PYTHON_BIN" -m picatalog "$@"
